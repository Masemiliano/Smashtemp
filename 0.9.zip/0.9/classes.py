import random
import global_vars
import pickle


def get_textsize(text, storlek):
    import pygame
    font = pygame.font.SysFont("", storlek)
    s = font.render(text, True, (0, 0, 0))
    tx, ty = s.get_size()
    return tx, ty


def pygame_input(surface, text, redan="", helskarm=True, rutplats=(0, 0), mussur=None):
    import pygame
    display = surface
    pyper = True
    try:
        import pyperclip
    except ModuleNotFoundError:
        pyper = False
    xh, yh = rutplats
    inputtat = redan
    plats = len(inputtat)
    forebild = pygame.Surface((1200, 620))
    forebild.blit(display, (0, 0))
    while True:
        if helskarm:
            display.fill((54, 100, 132))
        else:
            display.blit(forebild, (0, 0))
            pygame.draw.rect(display, (255, 255, 255), (xh, yh, get_textwidth(inputtat, 40), 40))
        skriv(display, text, (10, 30), 75)
        ev = pygame.event.poll()
        if ev.type == pygame.QUIT:
            pygame.quit()
            quit()
        if ev.type == pygame.KEYDOWN:
            keysh = pygame.key.get_pressed()
            if keysh[pygame.K_LEFT]:
                plats -= 1
                if plats < 0:
                    plats = 0
            if keysh[pygame.K_RIGHT]:
                plats += 1
                if plats > len(inputtat):
                    plats = len(inputtat)
            keyh = pygame.key.name(ev.key)
            klippt = False
            if keysh[pygame.K_LCTRL] or keysh[pygame.K_RCTRL]:
                if keysh[pygame.K_v] and pyper:
                    keyh = pyperclip.paste()
                    klippt = True
            shift = keysh[pygame.K_LSHIFT]
            if not shift:
                shift = keysh[pygame.K_RSHIFT]
            altgr = keysh[pygame.K_RCTRL]
            if not altgr:
                altgr = keysh[pygame.K_LCTRL]
            if keyh == "backspace":
                pa = -1
            elif keyh == "space":
                pa = " "
            elif keyh == "return":
                return inputtat
            else:
                if len(keyh) == 1:
                    if shift:
                        keyh = keyh.upper()
                        if keyh == "-":
                            keyh = "_"
                        elif keyh == "1":
                            keyh = "!"
                        elif keyh == "+":
                            keyh = "?"
                        elif keyh == "8":
                            keyh = "("
                        elif keyh == "9":
                            keyh = ")"
                        elif keyh == "3":
                            keyh = "#"
                        elif keyh == "0":
                            keyh = "="
                        elif keyh == "2":
                            keyh = '"'
                        elif keyh == "4":
                            keyh = "¤"
                        elif keyh == "5":
                            keyh = "%"
                        elif keyh == "'":
                            keyh = "*"
                        elif keyh == "6":
                            keyh = "&"
                        elif keyh == ".":
                            keyh = ":"
                        elif keyh == ",":
                            keyh = ";"
                        elif keyh == "<":
                            keyh = ">"
                        elif keyh == "7":
                            keyh = "/"
                    if altgr:
                        if keyh == "U":
                            keyh = "Ü"
                        if keyh == "u":
                            keyh = "ü"
                    pa = keyh
                else:
                    if klippt is False:
                        pa = ""
                    else:
                        pa = keyh

            if pa != "":
                inputtatny = ""
                numh = 0
                for vh in inputtat + "#":
                    if plats == numh:
                        if pa == -1:
                            inputtatny = inputtatny[:-1]
                        else:
                            inputtatny += pa
                    inputtatny += vh
                    numh += 1
                inputtat = inputtatny[:-1]
                if pa == -1:
                    plats -= 1
                    if plats < 0:
                        plats = 0
                else:
                    plats += 1
        if helskarm:
            skriv(display, inputtat, (10, 300), 40)
            pygame.draw.line(display, (0, 0, 0), (10 + get_textwidth(inputtat[:plats], 40), 300),
                             (10 + get_textwidth(inputtat[:plats], 40), 330))
        else:
            skriv(display, inputtat, rutplats, 40)
            pygame.draw.line(display, (0, 0, 0), (xh + get_textwidth(inputtat[:plats], 40), yh),
                             (xh + get_textwidth(inputtat[:plats], 40), yh + 30))
        if mussur:
            surface.blit(mussur, pygame.mouse.get_pos())
        pygame.display.update()


class knapp:
    def __init__(self, surface, text, pos=(0, 0), storlek=50, textfarg=(0, 0, 0)):
        self.text = text
        self.pos = pos
        self.storlek = storlek
        self.vidd = 0
        self.hoejd = 0
        self.farg = textfarg
        self.surface = surface

    def ar_aktiv(self):
        import pygame
        musx, musy = pygame.mouse.get_pos()
        self.vidd, self.hoejd = get_textsize(self.text, self.storlek)
        if self.pos[0] + self.vidd + 5 > musx > self.pos[0] - 5 and self.pos[1] - 5 < musy < self.pos[1] + self.hoejd + 5:
            return True
        return False

    def rita_runt(self):
        import pygame
        if self.ar_aktiv():
            pygame.draw.rect(self.surface, (255, 255, 255), (self.pos[0] - 5, self.pos[1] - 5, self.vidd + 10,
                                                             self.hoejd + 10))
            return True
        else:
            return False

    def rita(self):
        if self.ar_aktiv():
            self.rita_runt()
        skriv(self.surface, self.text, self.pos, self.storlek, self.farg)


class KickadError(Exception):
    pass


class entitet:
    def __init__(self, pos=(0, 0), typ=0, data=None, og=True):
        self.pos = pos
        self.typ = typ
        if data is not None:
            self.data = data.copy()
        else:
            self.data = []
        self.og = og  # original


class varldsdel:
    def __init__(self, pos=(0, 0), typ=1):
        self.pos = pos
        self.typ = typ
        self.entiteter = []


def vaddetborde(pos=(0, 0)):
    # min home-made extremt bra funktion som får seeds att funka, samtidigt som den försöker samla ihop biomes
    # förmodligen finns det buggade seeds gånger tusen, men det struntar jag i, det är ju liiite komplicerat

    def myround(z, base=5):
        return int(base * round(float(z) / base))

    mitten = (myround(pos[0], 5), myround(pos[1], 4))
    langd = abs(mitten[0] - pos[0]) + abs(mitten[1] - pos[1])

    random.seed(global_vars.seed + mitten[0] * 3.6 * 20.9 + mitten[1] * 4.9 * 54.7)
    svar = random.randint(0, 4)
    if svar == 4:
        svar = random.randint(0, 4)

    if langd > 0:
        random.seed(global_vars.seed + pos[0] * 3.6 * 20.9 + pos[1] * 4.9 * 54.7)
        if random.randint(-5, 4) > langd:
            svar = random.randint(0, 4)
            if svar == 4:
                svar = random.randint(0, 4)

    return svar


def ladda(ens_del, ds):  # ens_del är vilken del man står i, ds är delarssize
    rd = global_vars.render_distance  # rd är render distance
    aktivah = []
    for yh in range(-rd + ens_del[1], rd + ens_del[1] + 2):
        for xh in range(-rd + ens_del[0], rd + ens_del[0] + 2):
            try:
                bitfil = open(".data/.världar/" + global_vars.varldnamn + "/värld/" + str(xh) + "u" + str(yh), "rb")
                delh = pickle.load(bitfil)
                bitfil.close()
            except FileNotFoundError:
                delh = varldsdel((xh, yh), vaddetborde((xh, yh)))
                halfinns = False
                for num in range(0, 3900):
                    if random.randint(1, 440) == 1:
                        if delh.typ in (0, 1, 2, 3):
                            delh.entiteter.append(entitet((random.randint(0, ds), random.randint(0, ds)), delh.typ))
                        elif delh.typ == 4:
                            delh.entiteter.append(entitet((random.randint(0, ds), random.randint(0, ds)), 6))
                    if random.randint(1, 3000) == 1:  # svokli
                        delh.entiteter.append(entitet((random.randint(0, ds), random.randint(0, ds)), 4))
                    if random.randint(1, 30000) == 1:  # knecas
                        delh.entiteter.append(entitet((random.randint(0, ds), random.randint(0, ds)), 5))
                    if not halfinns and random.randint(1, 30000) == 1:  # hål
                        halfinns = True
                        djup = random.randint(0, 4)
                        if djup < 1:
                            djup = 1
                        delh.entiteter.append(entitet((random.randint(0, ds), random.randint(
                            0, ds)), 13, [djup, ]))
                        for numh in range(1, djup + 1):
                            fil = open(".data/.världar/" + global_vars.varldnamn + "/värld/hål" + str(
                                delh.pos[0]) + "u" + str(delh.pos[1]) + "u" + str(numh), "w")
                            for _ in range(0, 500):
                                if random.randint(1, 200) == 1:
                                    fil.write("15," + str(random.randint(100, 800)) + "," + str(
                                        random.randint(100, 400)) + ";")
                            fil.close()
                bitfil = open(".data/.världar/" + global_vars.varldnamn + "/värld/" + str(xh) + "u" + str(yh), "wb")
                pickle.dump(delh, bitfil)
                bitfil.close()
            aktivah.append(delh)
    random.seed()  # den sätter tillbaka seedet till ett random så att annat slumpmässigt inte påverkas av nyligen in-
    # laddad terräng
    return aktivah


def skriv(surface, text, pos=(0, 0), storlek=30, farg=(0, 0, 0), fetstil=False):
    display = surface
    import pygame
    font = pygame.font.SysFont("", storlek, fetstil)
    bildh = font.render(text, True, farg)
    display.blit(bildh, pos)


def get_textwidth(text, storlek):
    import pygame
    pygame.init()
    font = pygame.font.SysFont("", storlek)
    s = font.render(text, True, (0, 0, 0))
    tx, ty = s.get_size()
    return tx
