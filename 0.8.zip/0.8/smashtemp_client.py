import time


def klient(joina, klar, pygame_input, namn):
    import os
    import pygame
    import socket
    from _thread import start_new_thread

    pygame.init()

    def skriv(surface, text, pos=(0, 0), storlek=30, farg=(0, 0, 0), fetstil=False):
        display = surface
        font = pygame.font.SysFont("", storlek, fetstil)
        bildh = font.render(text, True, farg)
        display.blit(bildh, pos)

    gameDisplay = pygame.display.set_mode((1000, 600), pygame.RESIZABLE | pygame.SCALED | pygame.DOUBLEBUF)

    bilddir = ""
    if bilddir.strip() == "":
        bilddir = ".bilder"

    bildlista = []

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    if joina:
        s.connect((pygame_input(gameDisplay, "IP: ", "192.168."), 5555))  # int(input("Port: ").strip())))
    else:
        s.connect(("localhost", 5555))

    message, title, logga = s.recv(1024).decode().split("§")
    print(message)
    pygame.display.set_caption(title)

    s.sendall(namn.encode())

    bilder = s.recv(1024).decode()
    if bilder == "namnet":
        klar[0] = True
        pygame.quit()
        input("\n\nDu döpte dig till ett otillåtet namn eller ditt namn fanns redan på servern.")
        quit()
    bilder = bilder.split(",")

    for v in os.listdir(bilddir):
        if v.lower().replace(".png", "").replace(
                "ö", "o").replace("å", "a").replace("ä", "a") in bilder:
            globals()[v.lower().replace(".png", "").replace(
                "ö", "o").replace("å", "a").replace("ä", "a") + "bild"] = pygame.image.load(bilddir + "/" + v).\
                convert_alpha()  # snabbar upp

    if logga != "None":
        pygame.display.set_icon(globals()[logga.lower() + "bild"])

    s.sendall("Ok".encode())

    bildbackuplista = []

    inputta = False
    puttar = False

    pygame.event.set_allowed([pygame.QUIT, pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN])

    def server(_):
        nonlocal inputta, bildlista, inputtat, densevents, puttar, keys, posplus
        errornum = 0

        try:
            while 1:
                skaskicka = ""

                for event in densevents:
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        skaskicka += "mousebuttondown" + str(pygame.mouse.get_pos()).replace("(", "").replace(")", "") + "+"
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_m:
                            inputta = True
                            puttar = True
                            while puttar:
                                time.sleep(0.5)
                            skaskicka += "M:" + inputtat[2:] + "+"
                            inputtat = ""
                        if event.key == pygame.K_v:
                            skaskicka += "kd_v+"
                        if event.key == pygame.K_x:
                            skaskicka += "kd_x+"
                        if event.key == pygame.K_r:
                            skaskicka += "kd_r+"
                        if event.key == pygame.K_t:
                            skaskicka += "kd_t+"
                        if event.key == pygame.K_h:
                            skaskicka += "kd_h+"
                        if event.key == pygame.K_s:
                            skaskicka += "kd_s+"
                        if event.key == pygame.K_c:
                            skaskicka += "kd_c+"
                        if event.key == pygame.K_d:
                            skaskicka += "kd_d+"
                        if event.key == pygame.K_b:
                            skaskicka += "kd_b+"
                        if event.key == pygame.K_j:
                            skaskicka += "kd_j+"
                        if event.key == pygame.K_l:
                            skaskicka += "kd_l+"
                        if event.key == pygame.K_f:
                            skaskicka += "kd_f+"
                        if event.key == pygame.K_SPACE:
                            skaskicka += "kd_space+"
                        if event.key == pygame.K_RETURN:
                            skaskicka += "kd_return+"
                        if event.key == pygame.K_LEFT:
                            skaskicka += "kd_left+"
                        if event.key == pygame.K_RIGHT:
                            skaskicka += "kd_right+"
                        if event.key == pygame.K_UP:
                            skaskicka += "kd_up+"
                        if event.key == pygame.K_DOWN:
                            skaskicka += "kd_down+"
                        if event.key == pygame.K_g:
                            skaskicka += "kd_g+"

                densevents = []

                if keys[pygame.K_LEFT]:
                    skaskicka += "left+"
                if keys[pygame.K_RIGHT]:
                    skaskicka += "right+"
                if keys[pygame.K_UP]:
                    skaskicka += "up+"
                if keys[pygame.K_DOWN]:
                    skaskicka += "down+"
                if keys[pygame.K_x]:
                    skaskicka += "x+"
                if keys[pygame.K_v]:
                    skaskicka += "v+"
                if keys[pygame.K_SPACE]:
                    skaskicka += "space+"
                if keys[pygame.K_r]:
                    skaskicka += "r+"
                if keys[pygame.K_s]:
                    skaskicka += "s+"
                if keys[pygame.K_RETURN]:
                    skaskicka += "return+"
                if keys[pygame.K_LCTRL]:
                    skaskicka += "lctrl+"
                if keys[pygame.K_RCTRL]:
                    skaskicka += "rctrl+"
                if keys[pygame.K_g]:
                    skaskicka += "g+"

                if skaskicka:
                    skaskicka = skaskicka[:-1]
                else:
                    skaskicka = "inget"

                mottaget = s.recv(2048).decode()

                if inputtat:
                    s.sendall(inputtat.encode())
                    inputtat = ""
                else:
                    s.sendall(skaskicka.encode())

                try:
                    if mottaget != "inget":
                        if mottaget == "input":
                            inputta = True
                            puttar = True
                            while puttar:
                                time.sleep(0.5)
                        else:
                            bildlista = []
                            for vh in mottaget.split(";"):
                                if vh:
                                    try:
                                        bildlista.append(
                                            (vh.split(",")[0], (int(vh.split(",")[1]), int(vh.split(",")[2])), int(
                                                vh.split(",")[3]), float(vh.split(",")[4])))
                                    except IndexError:
                                        bildlista.append(
                                            (vh.split(",")[0], (int(vh.split(",")[1]), int(vh.split(",")[2])), 0, 1))
                            errornum = 0
                except Exception as eh:
                    print("Clienten har problem att ta emot data från servern: " + str(eh))
                    bildlista = bildbackuplista.copy()
                    errornum += 1
                    if errornum > 200:
                        klar[0] = True
                        s.close()
                        pygame.quit()
                        print("Klienten lyckades inte motta någon data på många försök. Du frånkopplades.")
                        quit()
                posplus = [0, 0]
        except Exception as eh:
            print(eh)
            print("Du avanslöt.")

    keys = pygame.key.get_pressed()

    start_new_thread(server, (None, ))

    inputtat = ""
    densevents = []
    posplus = [0, 0]

    while 1:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            posplus[0] += 1
        if keys[pygame.K_RIGHT]:
            posplus[0] -= 1
        if keys[pygame.K_UP]:
            posplus[1] += 1
        if keys[pygame.K_DOWN]:
            posplus[1] -= 1

        events = pygame.event.get()
        for v in events:
            densevents.append(v)

        for _ in events:
            if _.type == pygame.QUIT:
                klar[0] = True
                s.close()
                pygame.quit()
                quit()

        if inputta:
            inputtat = "S:" + pygame_input(gameDisplay, "Skriv något:")
            inputta = False
            puttar = False

        try:
            for v in bildlista:
                if v[0].__contains__("T:"):
                    skriv(gameDisplay, v[0][2:].replace("§", ",").replace("½", ";"), v[1])
                elif v[0].__contains__("F:"):
                    delat = v[0][2:].split(":")
                    farg = (int(delat[0]), int(delat[1]), int(delat[2]))
                    try:
                        rect = (int(delat[3]), int(delat[4]), int(delat[5]), int(delat[6]))
                        gameDisplay.fill(farg, rect)
                    except IndexError:
                        gameDisplay.fill(farg)
                elif v[0] == "extra_ljust":
                    gameDisplay.fill((50, 50, 50), special_flags=pygame.BLEND_RGB_ADD)
                else:
                    if v[3] != 1:
                        bild = pygame.transform.rotate(globals()[bilder[int(v[0])] + "bild"], v[2])
                        xhu, yhu = bild.get_size()
                        gameDisplay.blit(pygame.transform.scale(bild, (int(xhu * v[3]), int(yhu * v[3]))), v[1])
                    else:
                        if v[0].__contains__("i"):
                            gameDisplay.blit(pygame.transform.rotate(globals()[bilder[int(v[0].replace(
                                "i", ""))] + "bild"], v[2]), v[1])
                        else:
                            gameDisplay.blit(pygame.transform.rotate(globals()[bilder[int(v[0])] + "bild"], v[2]
                                                                 ), (v[1][0] + posplus[0], v[1][1] + posplus[1]))
        except Exception as e:
            print(e)

        pygame.display.update()

# from classes import *
# klient(True, [False], pygame_input)
