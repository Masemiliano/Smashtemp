import random

from classes import *


def server(varldnamn, multi, seed):
    import socket
    from _thread import start_new_thread
    import os
    import pickle
    import time
    import sys

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("", 5555))
    s.listen()

    if seed == "":
        seed = str(random.randint(-9999999999, 9999999999))

    if not seed.replace("-", "").isdigit():
        seed = str(hash(seed))

    print("Seed: " + seed + ".")

    try:
        os.mkdir(".data/.världar/" + varldnamn)
        varlden = varld(varldnamn)
        varldenfil = open(".data/.världar/" + varldnamn + "/värld", "wb")
        pickle.dump(varlden, varldenfil)
        varldenfil.close()
        filh = open(".data/.världar/" + varldnamn + "/seed", "w")
        filh.write(seed)
        filh.close()
    except FileExistsError:
        varldenfil = open(".data/.världar/" + varldnamn + "/värld", "rb")
        varlden = pickle.load(varldenfil)
        varldenfil.close()

    imp_list = [(-1, -1), (0, -1), (1, -1), (-1, 0), (0, 0), (1, 0), (-1, 1), (0, 1), (1, 1)]


    def klient(c, a):
        def xydelplus(delen, xy=(0, 0)):
            xyr = [xy[0], xy[1]]
            if xy[0] < 0:
                delen[0] -= 1
                xyr[0] = xy[0] + 700
            if xy[0] > 700:
                delen[0] += 1
                xyr[0] = xy[0] - 700
            if xy[1] < 0:
                delen[1] -= 1
                xyr[1] = xy[1] + 700
            if xy[1] > 700:
                delen[1] += 1
                xyr[1] = xy[1] - 700
            return xyr

        try:
            if True:
                # skicka = "inget"  # behövs inte
                x, y = 100, 100
                ensdel = [0, 0]
                updatedel = [0, 0]
                ryggsack = []
                handen = None

                namn = c.recv(512).decode()

                if len(namn) > 12:
                    namn = namn[:12]

                if namn in alla_anslutna:
                    namn = None
                    raise NamnFinnsRedan("NamnFinnsRedan: Namnet finns redan på servern!")

                spelaren = None
                ja = False
                for n in varlden.spelare:
                    if n.namn == namn:
                        ja = True
                        spelaren = n
                        x, y = spelaren.pos[0], spelaren.pos[1]
                        ensdel = [spelaren.pos[2], spelaren.pos[3]]
                        ryggsack = spelaren.ryggsack
                        handen = spelaren.handen

                if not ja:
                    spelaren = spelare(namn)
                    varlden.spelare.append(spelaren)
                    ryggsack = spelaren.ryggsack

                alla_anslutna.append(namn)

                allas_pos.append([ensdel[0], ensdel[1], x, y])

                c.send((str(x) + "," + str(y) + "," + str(ensdel[0]) + "," + str(ensdel[1]) + ":" + str(
                    handen)).encode())
                # skickar data som klienten behöver. Position och vad man har i handen
                c.recv(1024)  # måste få ett svar

                sanda_delar.append(0)  # sandadelar är variabeln som håller reda på när klienten behöver ny data om
                # miljön runt sig. Allas sådan variabel är dock i en gemensam lista för att en av klienterna ska kunna
                # begära uppdatering av allas omgivning, ifall man t.ex. hugger något

                allas_hall.append(0)

                ryggsacksskick = False

                print(namn + " är nu med och spelar.")

                while True:
                    spelaren.pos = (x, y, ensdel[0], ensdel[1])  # här kopieras allt till spelarens class, som finns i
                    spelaren.handen = handen                     # värld-classen, så när världen sparas så sparas det

                    # print(x, y)

                    delar_som_ska_sandas = []
                    skicka = "inget"

                    if ryggsacksskick:
                        skicka = "R:" + str(ryggsack).replace("[", "").\
                            replace("]", "").replace("'", "").replace(" ", '') + ":" + str(handen)
                        ryggsacksskick = False

                    if sanda_delar[alla_anslutna.index(namn)] < 10:
                        if sanda_delar[alla_anslutna.index(namn)] == 9:
                            sanda_delar[alla_anslutna.index(namn)] += 1
                        else:
                            for v in range(0, 9):
                                delar_som_ska_sandas.append(ladda_terrang(varlden, (ensdel[0] + imp_list[sanda_delar[
                                    alla_anslutna.index(
                                        namn)]][0], ensdel[1] + imp_list[sanda_delar[alla_anslutna.index(namn)]][1]),
                                                                          int(seed)))
                                sanda_delar[alla_anslutna.index(namn)] += 1

                    if delar_som_ska_sandas:
                        skicka = "D:"
                        for del_har in delar_som_ska_sandas:
                            skicka += "%" + str(str(del_har.miljo))

                            for v in del_har.entiteter:
                                skicka += ":" + str(v.typ) + "," + str(v.pos[0]) + "." + str(v.pos[1])

                        skicka += "/P:" + str(x) + "," + str(y) + "," + str(ensdel[0]) + "," + str(ensdel[1])

                    if skicka == "inget":
                        skicka = "S"  # spelare
                        for num in range(0, len(allas_pos)):
                            if num != alla_anslutna.index(namn):
                                if abs(allas_pos[num][0] - ensdel[0]) < 2 and abs(allas_pos[num][1] - ensdel[1]) < 2:
                                    skicka += ":" + alla_anslutna[num] + "," + str(allas_pos[num][0]) + "," + \
                                              str(allas_pos[num][1]) + "," \
                                              + str(allas_pos[num][2]) + "," + str(allas_pos[num][3]) + "," + \
                                              str(allas_hall[num])
                        if skicka == "S":
                            skicka = "inget"

                    c.sendall(skicka.encode())

                    mottaget = c.recv(512).decode()

                    posdata, events = mottaget.split("+")
                    events = events.split("/")

                    if sanda_delar[alla_anslutna.index(namn)] == 10:  # i övergången mellan olika omgivningar så kan
                        # klientens x och y vara mer än 700 eller mindre än 0 flera frames, före servern rättar den

                        updatedel = ensdel.copy()

                        x, y = int(posdata.split(",")[0]), int(posdata.split(",")[1])

                        allas_hall[alla_anslutna.index(namn)] = int(posdata.split(",")[2])

                        # Under här checkar den helt enkelt om man har gått in i en ny chunk och om man har det
                        # korrigeras ens_del, x och y. Då uppdateras också ens omgivning
                        if x > 700 or x < 0 or y > 700 or y < 0:
                            x, y = xydelplus(ensdel, (x, y))
                            sanda_delar[alla_anslutna.index(namn)] = 0
                    else:  # om det är mitt i en övergång så håller den reda på om clienten fortsätter gå och fixar
                        # då x och
                        # y efter det
                        x, y = int(posdata.split(",")[0]), int(posdata.split(",")[1])

                        # det den gör basically: den kommer ihåg vad ens förra del var, och fixar då x och y så att
                        # de borde passa i den nya delen. Om man då går tillbaka in i samma del som man började i så
                        # kommer den så fort den uppdaterat märka att man bytt igen
                        if updatedel[0] > ensdel[0]:
                            x += 700
                        elif updatedel[0] < ensdel[0]:
                            x -= 700
                        if updatedel[1] > ensdel[1]:
                            y += 700
                        elif updatedel[1] < ensdel[1]:
                            y -= 700

                    for v in events:
                        if v[:2] == "x:":
                            klar = False

                            for spec in [(0, 0), (-1, -1), (-1, 0), (0, -1)]:  # den måste kolla i alla delar till
                                # vänster och över, för växter kan sticka in därifrån
                                if klar:
                                    break

                                harpos = int(v[2:].split(".")[0]), int(
                                    v[2:].split(".")[1])  # extractar datan från meddelandet

                                hardel = ensdel.copy()  # Den plussar på detta om krysset är på t.ex. x 720, och minusar
                                # om det är t.ex. y -50. You get the point

                                harpos = xydelplus(hardel, (harpos[0], harpos[1]))

                                hardel[0] += spec[0]
                                hardel[1] += spec[1]

                                harpos[0] += -spec[0] * 700
                                harpos[1] += -spec[1] * 700

                                # Här hittas växten och tas bort. Det fixas
                                # också en global_update och lägger till den huggna saken i ryggsäcken.

                                if varlden.delplatser.__contains__((hardel[0], hardel[1])):  # annars kan det bli error
                                    delh = varlden.delar[varlden.delplatser.index((hardel[0], hardel[1]))]  # den
                                    # kollar i sitt "register" var i listan som delen är, så att den inte behöver
                                    # loopa igenom alla delar

                                    for ent in delh.entiteter:
                                        if ent.pos[0] + vaxtsizes[ent.typ][0] >= harpos[0] >= ent.pos[0]:
                                            if ent.pos[1] + vaxtsizes[ent.typ][1] >= harpos[1] >= ent.pos[1]:
                                                ryggsack.append(vaxtlista[delh.entiteter.pop(delh.entiteter.index(ent)).
                                                                typ])

                                                for num in range(0, len(sanda_delar)):  # här sätter den allas värde
                                                    sanda_delar[num] = 0  # till 0 vilket innebär att allas miljö
                                                    # uppdateras

                                                klar = True
                                                break
                        if v[:2] == "v:" and handen is not None:
                            harpos = int(v[2:].split(".")[0]), int(
                                v[2:].split(".")[1])  # extractar datan från meddelandet

                            hardel = ensdel.copy()  # Den plussar på detta om krysset är på t.ex. x 720, och minusar
                            # om det är t.ex. y -50. You get the point

                            harpos = xydelplus(hardel, (harpos[0], harpos[1]))
                            delh = varlden.delar[varlden.delplatser.index((hardel[0], hardel[1]))]

                            if len(delh.entiteter) < 20:
                                delh.entiteter.append(entitet(harpos, vaxtlista.index(handen)))
                                if ryggsack.__contains__(handen):
                                    ryggsack.pop(ryggsack.index(handen))
                                else:
                                    handen = None

                                for num in range(0, len(sanda_delar)):  # här sätter den allas värde
                                    sanda_delar[num] = 0  # till 0 vilket innebär att allas miljö
                                    # uppdateras
                        if v == "r":  # öppnar ryggsäcken
                            ryggsacksskick = True
                        if v[:2] == "h:":  # sätter något i handen
                            if handen is not None:
                                ryggsack.append(handen)
                            handen = ryggsack[int(v[2:])]
                            ryggsack.pop(int(v[2:]))
                        if v == "t":  # sätter ner saken i ryggsäcken
                            if handen is not None:
                                ryggsack.append(handen)
                            handen = None



                    allas_pos[alla_anslutna.index(namn)] = [ensdel[0], ensdel[1], x, y]


        except Exception as e:
            print("\n" + str(namn) + " avanslöt.")
            exc_type, _, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print("Detaljerad beskrivning: " + str(exc_type) + "  ...  " + str(e) + "  ...  " + str(fname) +
                  " at line " + str(exc_tb.tb_lineno))

            # det här ovanför samlar in info om errorn som orsakade avanslutningen, och printar det

            if namn is not None:
                allas_pos.pop(alla_anslutna.index(namn))
                sanda_delar.pop(alla_anslutna.index(namn))
                allas_hall.pop(alla_anslutna.index(namn))
                alla_anslutna.pop(alla_anslutna.index(namn))

    alla_anslutna = []
    sanda_delar = []
    allas_pos = []
    allas_hall = []


    def skum_server(_):
        while True:
            time.sleep(5)
            fil = open(".data/.världar/" + varlden.namn + "/värld", "wb")
            pickle.dump(varlden, fil)
            fil.close()

    start_new_thread(skum_server, (None, ))


    if multi:
        print("Servern har startat upp.\n")
        while True:
            conn, addr = s.accept()
            print(str(addr) + " anslöt.")
            start_new_thread(klient, (conn, addr))
    else:
        conn, addr = s.accept()
        start_new_thread(klient, (conn, addr))

        while True:
            time.sleep(20)


if __name__ == "__main__":
    varld = input("Värld: ")
    try:
        fil = open(".data/.världar/" + varld + "/seed", "r")
        server(varld, False, fil.read())
        fil.close()
    except FileNotFoundError:
        server(input("Värld: "), True, input("Seed: "))
