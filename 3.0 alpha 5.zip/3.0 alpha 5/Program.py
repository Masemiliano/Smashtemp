import time
import pygame

from server import server
from client import client
from _thread import start_new_thread
from classes import *

pygame.init()

display = pygame.display.set_mode((1000, 600), pygame.RESIZABLE | pygame.SCALED)

pygame.display.set_caption("Smashtemp 3.0 alphaversion 3")

logga = pygame.transform.scale(pygame.image.load(".bilder/Logga.png"), (1000, 600))

singleknapp = knapp(display, "Singleplayer", (200, 150))
joinaknapp = knapp(display, "Joina en server", (200, 250))
hostaknapp = knapp(display, "Hosta en server", (200, 350))

while True:
    display.fill((0, 50, 67))
    display.blit(logga, (0, 0))

    singleknapp.rita()
    joinaknapp.rita()
    hostaknapp.rita()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if singleknapp.ar_aktiv():
                stoppcheck = [False]

                varld = pygame_input(display, "Värld: ")
                try:
                    fil = open(".data/.världar/" + varld + "/seed", "r")
                    start_new_thread(server, (varld, False, fil.read()))
                    fil.close()
                except FileNotFoundError:
                    start_new_thread(server, (varld, False, pygame_input(display, "Seed:")))

                pygame.quit()
                start_new_thread(client, (stoppcheck, "localhost"))

                while True:
                    time.sleep(2)
                    if stoppcheck[0]:
                        print("Sparar... Stäng inte programmet...")
                        time.sleep(5)  # för att vänta på att servern sparar allting
                        quit()

            if joinaknapp.ar_aktiv():
                stoppcheck = [False]

                ip = pygame_input(display, "IP:", "192.168.")

                pygame.quit()
                start_new_thread(client, (stoppcheck, ip))

                while True:
                    time.sleep(2)
                    if stoppcheck[0]:
                        print("Sparar... Stäng inte programmet...")
                        time.sleep(5)  # för att vänta på att servern sparar allting
                        quit()
            if hostaknapp.ar_aktiv():
                stoppcheck = [False]

                varld = pygame_input(display, "Värld: ")
                try:
                    fil = open(".data/.världar/" + varld + "/seed", "r")
                    start_new_thread(server, (varld, True, fil.read()))
                    fil.close()
                except FileNotFoundError:
                    start_new_thread(server, (varld, True, pygame_input(display, "Seed:")))


                pygame.quit()
                start_new_thread(client, (stoppcheck, "localhost"))

                while True:
                    time.sleep(20)

    pygame.display.update()
