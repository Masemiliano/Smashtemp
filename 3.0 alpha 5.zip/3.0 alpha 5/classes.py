import random
import pickle


vaxtlista = ["öhlyt", "weclurt", "ebux", "spuqav", "oxlurt", "svokli"]
vaxtsizes = [(100, 100), (100, 100), (100, 200), (100, 200), (100, 100), (60, 60)]


class entitet:
    def __init__(self, pos, typ):
        self.pos = pos
        self.typ = typ


class varldsdel:
    def __init__(self, pos, entiteter=None, miljo=0):
        self.miljo = miljo
        self.pos = pos
        if entiteter is None:
            self.entiteter = []
        else:
            self.entiteter = entiteter


class varld:
    def __init__(self, namn):
        self.delar = []
        self.delplatser = []  # det borde snabba på uppsökningstiden, det är basically ett register
        self.namn = namn
        self.spelare = []


class spelare:
    def __init__(self, namn, pos=(100, 100, 0, 0), ryggsack=None, handen=None):
        if ryggsack is None:
            ryggsack = []
        self.namn = namn
        self.pos = pos
        self.ryggsack = ryggsack
        self.handen = handen


class NamnFinnsRedan(Exception):
    pass


def vaddetborde(seed, pos=(0, 0)):
    # min home-made extremt bra funktion som får seeds att funka, samtidigt som den försöker samla ihop biomes
    # förmodligen finns det buggade seeds gånger tusen, men det struntar jag i, det är ju liiite komplicerat

    def myround(z, base=3):
        return int(base * round(float(z) / base))

    distance = abs(0 - pos[0]) + abs(0 - pos[1])

    if distance > 10:
        if distance < 13:
            svar = 6
        else:
            svar = 5
        random.seed(seed + pos[0] * 3.6 * 20.9 + pos[1] * 4.9 * 54.7)
        if random.randint(1, 8 + int(distance / 3)) == 1:
            svar = random.randint(0, 4)
            if random.randint(1, 10) == 1:
                svar = 7
    else:
        mitten = (myround(pos[0], 3), myround(pos[1], 3))
        langd = abs(mitten[0] - pos[0]) + abs(mitten[1] - pos[1])

        random.seed(seed + mitten[0] * 3.6 * 20.9 + mitten[1] * 4.9 * 54.7)
        svar = random.randint(0, 4)
        if svar == 4:
            svar = random.randint(0, 4)

        if langd > 0:
            random.seed(seed + pos[0] * 3.6 * 20.9 + pos[1] * 4.9 * 54.7)
            if random.randint(-5, 4) > langd:
                svar = random.randint(0, 4)
                if svar == 4:
                    svar = random.randint(0, 4)

    return svar


def ladda_terrang(varlden, pos, seed):
    ja = None

    for v in varlden.delar:
        if v.pos == pos:
            ja = v
            break

    if ja is None:
        ny_del = varldsdel(pos)
        ny_del.miljo = vaddetborde(seed, pos)
        for _ in range(0, 5000):
            if ny_del.miljo in (0, 1, 2, 3, 4) and random.randint(1, 700) == 1:
                ny_entitet = entitet((random.randint(0, 700), random.randint(0, 700)), ny_del.miljo)
                ny_del.entiteter.append(ny_entitet)
            if random.randint(1, 1000) == 1:
                ny_entitet = entitet((random.randint(0, 700), random.randint(0, 700)), 5)
                ny_del.entiteter.append(ny_entitet)

        varlden.delar.append(ny_del)
        varlden.delplatser.append(ny_del.pos)
        fil = open(".data/.världar/" + varlden.namn + "/värld", "wb")
        pickle.dump(varlden, fil)
        fil.close()
        return ny_del

    else:
        return ja


def get_textsize(text, storlek):
    import pygame
    pygame.init()
    font = pygame.font.SysFont("", storlek)
    s = font.render(text, True, (0, 0, 0))
    tx, ty = s.get_size()
    return tx, ty


def skriv(surface, text, pos=(0, 0), storlek=30, farg=(0, 0, 0), fetstil=False):
    display = surface
    import pygame
    pygame.init()
    font = pygame.font.SysFont("", storlek, fetstil)
    bildh = font.render(text, True, farg)
    display.blit(bildh, pos)


def pygame_input(surface, text, redan="", helskarm=True, rutplats=(0, 0), mussur=None, retpakryss=False):
    import pygame
    pygame.init()
    display = surface
    pyper = True
    try:
        import pyperclip
    except ModuleNotFoundError:
        pyper = False
    xh, yh = rutplats
    inputtat = redan
    plats = len(inputtat)
    forebild = pygame.Surface((1200, 620))
    forebild.blit(display, (0, 0))
    while True:
        if helskarm:
            display.fill((54, 100, 132))
        else:
            display.blit(forebild, (0, 0))
            pygame.draw.rect(display, (255, 255, 255), (xh, yh, get_textsize(inputtat, 40)[0], 40))
        skriv(display, text, (10, 30), 75)
        ev = pygame.event.poll()
        if ev.type == pygame.QUIT:
            if retpakryss:
                return None
            else:
                pygame.quit()
                quit()
        if ev.type == pygame.KEYDOWN:
            keysh = pygame.key.get_pressed()
            if keysh[pygame.K_LEFT]:
                plats -= 1
                if plats < 0:
                    plats = 0
            if keysh[pygame.K_RIGHT]:
                plats += 1
                if plats > len(inputtat):
                    plats = len(inputtat)
            keyh = pygame.key.name(ev.key)
            klippt = False
            if keysh[pygame.K_LCTRL] or keysh[pygame.K_RCTRL]:
                if keysh[pygame.K_v] and pyper:
                    keyh = pyperclip.paste()
                    klippt = True
            shift = keysh[pygame.K_LSHIFT]
            if not shift:
                shift = keysh[pygame.K_RSHIFT]
            altgr = keysh[pygame.K_RCTRL]
            if not altgr:
                altgr = keysh[pygame.K_LCTRL]
            if keyh == "backspace":
                pa = -1
            elif keyh == "space":
                pa = " "
            elif keyh == "return":
                return inputtat
            else:
                if len(keyh) == 1:
                    if shift:
                        keyh = keyh.upper()
                        if keyh == "-":
                            keyh = "_"
                        elif keyh == "1":
                            keyh = "!"
                        elif keyh == "+":
                            keyh = "?"
                        elif keyh == "8":
                            keyh = "("
                        elif keyh == "9":
                            keyh = ")"
                        elif keyh == "3":
                            keyh = "#"
                        elif keyh == "0":
                            keyh = "="
                        elif keyh == "2":
                            keyh = '"'
                        elif keyh == "4":
                            keyh = "¤"
                        elif keyh == "5":
                            keyh = "%"
                        elif keyh == "'":
                            keyh = "*"
                        elif keyh == "6":
                            keyh = "&"
                        elif keyh == ".":
                            keyh = ":"
                        elif keyh == ",":
                            keyh = ";"
                        elif keyh == "<":
                            keyh = ">"
                        elif keyh == "7":
                            keyh = "/"
                    if altgr:
                        if keyh == "U":
                            keyh = "Ü"
                        if keyh == "u":
                            keyh = "ü"
                    pa = keyh
                else:
                    if klippt is False:
                        pa = ""
                    else:
                        pa = keyh

            if pa != "":
                inputtatny = ""
                numh = 0
                for vh in inputtat + "#":
                    if plats == numh:
                        if pa == -1:
                            inputtatny = inputtatny[:-1]
                        else:
                            inputtatny += pa
                    inputtatny += vh
                    numh += 1
                inputtat = inputtatny[:-1]
                if pa == -1:
                    plats -= 1
                    if plats < 0:
                        plats = 0
                else:
                    plats += 1
        if helskarm:
            skriv(display, inputtat, (10, 300), 40)
            pygame.draw.line(display, (0, 0, 0), (10 + get_textsize(inputtat[:plats], 40)[0], 300),
                             (10 + get_textsize(inputtat[:plats], 40)[0], 330))
        else:
            skriv(display, inputtat, rutplats, 40)
            pygame.draw.line(display, (0, 0, 0), (xh + get_textsize(inputtat[:plats], 40)[0], yh),
                             (xh + get_textsize(inputtat[:plats], 40)[0], yh + 30))
        if mussur:
            surface.blit(mussur, pygame.mouse.get_pos())
        pygame.display.update()


class knapp:
    def __init__(self, surface, text, pos=(0, 0), storlek=50, textfarg=(0, 0, 0)):
        self.text = text
        self.pos = pos
        self.storlek = storlek
        self.vidd = 0
        self.hoejd = 0
        self.farg = textfarg
        self.surface = surface

    def ar_aktiv(self):
        import pygame
        pygame.init()
        musx, musy = pygame.mouse.get_pos()
        self.vidd, self.hoejd = get_textsize(self.text, self.storlek)
        if self.pos[0] + self.vidd + 5 > musx > self.pos[0] - 5 and self.pos[1] - 5 < musy < self.pos[1] + self.hoejd \
                + 5:
            return True
        return False

    def rita_runt(self):
        import pygame
        pygame.init()
        if self.ar_aktiv():
            pygame.draw.rect(self.surface, (255, 255, 255), (self.pos[0] - 5, self.pos[1] - 5, self.vidd + 10,
                                                             self.hoejd + 10))
            return True
        else:
            return False

    def rita(self):
        if self.ar_aktiv():
            self.rita_runt()
        skriv(self.surface, self.text, self.pos, self.storlek, self.farg)
