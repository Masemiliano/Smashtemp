def client(stopp, ip):
    import pygame
    import socket
    from _thread import start_new_thread
    import os
    from classes import skriv, get_textsize, vaxtlista, vaxtsizes
    import random
    import multiprocessing

    class cliententitet:
        def __init__(self, pos, typ):
            self.pos = pos
            self.typ = typ

    class clientdel:
        def __init__(self):
            self.entiteter = []
            self.miljo = 0

    port = 5555

    c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    c.connect((ip, port))

    try:
        fil = open(".data/Namn", "r")
        namn = fil.read()
        fil.close()
    except FileNotFoundError:
        namn = input("Vad vill du kallas? ")
        fil = open(".data/Namn", "w")
        fil.write(namn)
        fil.close()

    c.sendall(namn.encode())

    def fixa_ryggsacksbilden(vald=0):
        ryggsackbild.fill((45, 67, 87))
        xh, yh = 30, 30
        num = 0
        for r in ryggsack:
            ryggsackbild.blit(pygame.transform.scale(globals()[r + "bild"], (30, 30)), (xh, yh))
            skriv(ryggsackbild, r, (xh + 40, yh))
            if num == vald:
                ryggsackbild.fill((0, 255, 0), (xh + 40, yh + 20, get_textsize(r, 30)[0], 3))

            xh += get_textsize(r, 30)[0] + 83
            if (num + 1) % 5 == 0:
                yh += 60
                xh = 30

            num += 1

    def cinect(_):  # connectionen med servern
        nonlocal delar, x, y, order, xn, yn, update, ensdel, forradel, spelare, ryggsackoppen, ryggsack, ryggsackbild, \
            handen, waitaminute, rvald

        while True:
            mottaget = c.recv(2048).decode()
            if mottaget[:2] == "D:":  # del eller data

                delar = []
                deldataor = mottaget.split("/")[0].split("%")
                deldataor.pop(0)
                for v in deldataor:
                    ny_del = clientdel()
                    ny_del.miljo = int(v[0])

                    if v.__contains__(":"):
                        datapieces = v.split(":")
                        datapieces.pop(0)

                        for vh in datapieces:
                            if vh:
                                pos = (int(vh.split(",")[1].split(".")[0]), int(vh.split(",")[1].split(".")[1]))
                                typ = int(vh.split(",")[0])
                                ny_del.entiteter.append(cliententitet(pos, typ))

                    delar.append(ny_del)

                # DET SOM TIDIGARE VAR UNDER P: FOR SOME REASON

                # den har transparent på sig och måste därför fyllas så att de gamla växterna inte är kvar
                entladdbild.fill((255, 255, 255, 0))

                delnum = 0
                for v in delar:
                    specpos = (blitting[delnum][0] + 700, blitting[delnum][1] + 700)
                    bakladdbild.blit(globals()["bakgrund" + str(v.miljo) + "bild"], specpos)

                    delnum += 1

                delnum = 0
                for v in delar:
                    for v2 in v.entiteter:
                        specpos = (blitting[delnum][0] + v2.pos[0] + 700, blitting[delnum][1] + v2.pos[1] + 700)
                        entladdbild.blit(globals()[vaxtlista[v2.typ] + "bild"], specpos)

                    delnum += 1

                forradel = ensdel.copy()
                xn, yn, ensdel = int(mottaget.split("/")[1][2:].split(",")[0]), int(mottaget.split("/")[1][2:].
                                                                                    split(",")[1]), [
                                     int(mottaget.split("/")[1][2:].split(",")[2]),
                                     int(mottaget.split("/")[1][2:].split(",")[3])]
                update = True  # fixar så att rit-threadet inte hinner rita förrän x och y är uppdaterade

            if mottaget[:2] == "R:":
                r = mottaget[2:].split(":")[0]
                h = mottaget[2:].split(":")[1]

                if h == "None":
                    handen = None
                else:
                    handen = h

                if not waitaminute:
                    rvald = 0
                    ryggsackoppen = not ryggsackoppen
                waitaminute = False

                if ryggsackoppen:
                    if r:
                        ryggsack = r.split(",")

                    fixa_ryggsacksbilden(rvald)

            if mottaget[:2] == "S:":  # spelare
                spelare = []
                for v in mottaget[2:].split(":"):
                    spelare.append((v.split(",")[0], int(v.split(",")[1]), int(v.split(",")[2]), int(v.split(",")[3]),
                                    int(v.split(",")[4]), int(v.split(",")[5])))
            else:
                spelare = []

            if update:  # om rit-threadet inte fattat att x och y uppdaterats så skickar detta threadet ändå de nya
                # uppdaterade koordinaterna
                skicka = str(int(xn)) + "," + str(int(yn)) + "," + str(hall)
            else:
                skicka = str(int(x)) + "," + str(int(y)) + "," + str(hall)

            skicka += "+"
            for vh in order:
                skicka += vh + "/"
            order = []

            if not skicka[-1] == "+":  # om inga order skickas måste ändå plusset vara kvar pga splittingen i servern
                skicka = skicka[:-1]

            c.sendall(skicka.encode())

    delar = []
    ensdel = [0, 0]
    forradel = [0, 0]
    x, y = 100, 100
    xn, yn = 100, 100  # när den uppdaterar behöver x, y och laddbild uppdateras i rit-threadet. Därför sätter socket-
    # threadet 'update' till True och uppdaterar temporära variabler som sen rit-threadet tar åt sig.
    hall = 0
    order = []

    fordata = c.recv(1024).decode()

    posar = fordata.split(":")[0]

    handen = fordata.split(":")[1]
    if handen == "None":
        handen = None

    x, y = int(posar.split(",")[0]), int(posar.split(",")[1])
    xn, yn = int(posar.split(",")[0]), int(posar.split(",")[1])
    ensdel = [int(posar.split(",")[2]), int(posar.split(",")[3])]
    forradel = [int(posar.split(",")[2]), int(posar.split(",")[3])]

    c.send("bullshit".encode())

    bot = False

    update = False

    blitting = [(-700, -700), (0, -700), (700, -700), (-700, 0), (0, 0), (700, 0), (-700, 700), (0, 700), (700, 700)]
    krysspos = [(20, -40), (-40, 20), (20, 80), (80, 20)]

    entiteterbild = pygame.Surface((2100, 2100), pygame.SRCALPHA)  # dessa två behöver vara
    entladdbild = pygame.Surface((2100, 2100), pygame.SRCALPHA)  # transparenta
    bakgrundsbild = pygame.Surface((2100, 2100))
    bakladdbild = pygame.Surface((2100, 2100))

    spelare = []

    for bild in os.listdir(".bilder"):
        globals()[bild.lower().replace(".png", "") + "bild"] = pygame.image.load(".bilder/" + bild)
        size = globals()[bild.lower().replace(".png", "") + "bild"].get_size()
        globals()[bild.lower().replace(".png", "") + "liten"] = pygame.transform.scale(
            globals()[bild.lower().replace(".png", "") + "bild"], (int(size[0] / 3), int(size[1] / 3)))
        # laddar både vanliga bilden och en liten version av den

    start_new_thread(cinect, (None,))

    gameDisplay = pygame.display.set_mode((1000, 600), pygame.RESIZABLE | pygame.SCALED)

    ryggsackoppen = False
    ryggsack = []
    ryggsackbild = pygame.Surface((800, 400))
    rvald = 0  # ryggsäcksvald

    waitaminute = False  # den används till att uppdatera ryggsäcken utan att gå ut ur den. Om denna är True så gås inte
    # ryggsäcken ut ur vid nästa uppdatering

    clock = pygame.time.Clock()

    while True:
        if update:  # ska vara först så att man sen ändå rör sig samma frame. Om det är sist så rör man sig och sen
            # hoppar man tillbaka pyttelite

            entiteterbild = entladdbild.copy()
            bakgrundsbild = bakladdbild.copy()

            # Den räknar ut ens nya x och y baserat på var den nya delen ligger i förhållande till den gamla.
            # Detta är bra för då om man gått in i en ny del under uppdateringen så kommer x eller y vara för stora
            # eller små och en ny update kommer genast ske
            if forradel[0] < ensdel[0]:
                x -= 700
            elif forradel[0] > ensdel[0]:
                x += 700
            if forradel[1] < ensdel[1]:
                y -= 700
            elif forradel[1] > ensdel[1]:
                y += 700

            update = False

        tid = clock.tick(60)
        custom_speed = tid * 0.001 * 320

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                stopp[0] = True
                quit()
            if event.type == pygame.KEYDOWN:
                key = pygame.key.get_pressed()
                if key[pygame.K_x]:
                    order.append("x:" + str(int(x + krysspos[hall][0])) + "." + str(int(y + krysspos[hall][1])))
                if key[pygame.K_v]:
                    if 701 > x > -1 and 701 > y > -1:
                        if handen is not None:
                            size = vaxtsizes[vaxtlista.index(handen)]  # used to sätta ut växten i mitten på krysset

                            order.append("v:" + str(int(x + krysspos[hall][0] - size[0] / 2)) + "." + str(int(
                                y + krysspos[hall][1] - size[1] / 2)))
                            if ryggsack.__contains__(handen):
                                ryggsack.pop(ryggsack.index(handen))
                            else:
                                handen = None
                if key[pygame.K_r]:
                    order.append("r")
                if ryggsackoppen:
                    if key[pygame.K_LEFT]:
                        if rvald - 1 >= 0:
                            rvald -= 1
                            fixa_ryggsacksbilden(rvald)
                    if key[pygame.K_RIGHT]:
                        if rvald + 1 < len(ryggsack):
                            rvald += 1
                            fixa_ryggsacksbilden(rvald)
                    if key[pygame.K_UP]:
                        if rvald - 5 >= 0:
                            rvald -= 5
                            fixa_ryggsacksbilden(rvald)
                    if key[pygame.K_DOWN]:
                        if rvald + 5 < len(ryggsack):
                            rvald += 5
                            fixa_ryggsacksbilden(rvald)
                    if key[pygame.K_t]:
                        if handen is not None:
                            order.append("t")
                            order.append("r")
                            waitaminute = True
                            handen = None
                    if key[pygame.K_h]:
                        handen = ryggsack[rvald]
                        order.append("h:" + str(rvald))
                        order.append("r")
                        waitaminute = True
                    if key[pygame.K_KP_ENTER] or key[pygame.K_RETURN]:
                        nej = False
                        irvald = 0  # i ryggsäcken vald
                        while not nej:
                            for event2 in pygame.event.get():
                                if event2.type == pygame.KEYDOWN:
                                    key2 = pygame.key.get_pressed()
                                    if key2[pygame.K_KP_ENTER] or key2[pygame.K_RETURN]:
                                        nej = True
                                        if irvald == 1:
                                            handen = ryggsack[rvald]
                                            order.append("h:" + str(rvald))
                                            order.append("r")
                                            waitaminute = True
                                    if key2[pygame.K_DOWN]:
                                        irvald += 1
                                    if key2[pygame.K_UP]:
                                        if irvald - 1 >= 0:
                                            irvald -= 1
                            gameDisplay.fill((45, 67, 87), (100, 100, 800, 400))
                            skriv(gameDisplay, "Avbryt", (200, 200), 50)
                            skriv(gameDisplay, "Sätt i handen", (200, 250), 50)
                            skriv(gameDisplay, "Smasha", (200, 300), 50)
                            gameDisplay.fill((0, 255, 0), (200, 238 + irvald * 50, 200, 5))
                            pygame.display.update()

        if not ryggsackoppen:
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                x -= custom_speed
                hall = 1
            if keys[pygame.K_RIGHT]:
                x += custom_speed
                hall = 3
            if keys[pygame.K_UP]:
                y -= custom_speed
                hall = 0
            if keys[pygame.K_DOWN]:
                y += custom_speed
                hall = 2

        if bot:
            if random.randint(1, 500) == 1:
                hall = random.randint(0, 3)
            if hall == 1:
                x -= custom_speed
            if hall == 3:
                x += custom_speed
            if hall == 0:
                y -= custom_speed
            if hall == 2:
                y += custom_speed

        gameDisplay.fill((255, 255, 255))  # no idea why this is still here (eller jo om man då har extremt dålig
        # överföring och går utanför sin inladdade 3x3-bild så är det vitt där)

        # här blittas bakgrunden till alla delar, som beror på miljön
        gameDisplay.blit(bakgrundsbild, (-700 - x + 480, -700 - y + 280))

        # under här blittas alla andra spelare
        for s in spelare:

            plusx, plusy = 0, 0
            if s[1] < ensdel[0]:
                plusx = -700
            elif s[1] > ensdel[0]:
                plusx = 700
            if s[2] < ensdel[1]:
                plusy = -700
            elif s[2] > ensdel[1]:
                plusy = 700

            gameDisplay.blit(pygame.transform.rotate(globals()["svilqbild"], s[5] * 90), (s[3] + plusx + 480 - x, s[4]
                                                                                          + plusy + 280 - y))
            skriv(gameDisplay, s[0], (s[3] + plusx + 480 - x, s[4] + plusy + 280 - y))

        # man själv blittas
        gameDisplay.blit(pygame.transform.rotate(globals()["svilqbild"], hall * 90), (480, 280))

        # här blittas alla växter, ovanpå eventuella spelare
        gameDisplay.blit(entiteterbild, (-700 - x + 480, -700 - y + 280))

        # här blittas minimappen
        gameDisplay.fill((156, 75, 101), (845, 445, 110, 110))
        gameDisplay.blit(pygame.transform.scale(bakgrundsbild, (100, 100)), (850, 450))

        # krysset blittas
        gameDisplay.blit(globals()["kryssbild"], (480 + krysspos[hall][0], 280 + krysspos[hall][1]))
        # det man håller i handen blittas, och korrigeras så att krysset hamnar i mitten på bilden
        if handen is not None:
            size = globals()[handen + "liten"].get_size()
            gameDisplay.blit(globals()[handen + "liten"],
                             (480 + krysspos[hall][0] - size[0] / 2, 280 + krysspos[hall][1] - size[1] / 2))

        # ens position skrivs
        gameDisplay.fill((255, 255, 255), (0, 0, 170, 25))
        skriv(gameDisplay, str(ensdel[0]) + "," + str(ensdel[1]) + "*" + str(int(x)) + "," + str(int(y)))

        # ritar ryggsäcken
        if ryggsackoppen:
            gameDisplay.blit(ryggsackbild, (100, 100))

        # whatever
        pygame.display.update()


if __name__ == "__main__":
    stoppu = [False]
    client(stoppu, input("IP: "))
