import time

import pygame
from classes import *
from _thread import start_new_thread
from smashtemp_server import server
from smashtemp_client import klient


pygame.init()

gameDisplay = pygame.display.set_mode((1000, 600), pygame.RESIZABLE | pygame.SCALED)

logga = pygame.image.load(".bilder/Logga.png")
logga = pygame.transform.scale(logga, (1000, 600))

singleknapp = knapp(gameDisplay, "Singleplayer", (200, 140))
multiknapp = knapp(gameDisplay, "Hosta en server", (200, 240))
joinaknapp = knapp(gameDisplay, "Joina en server", (200, 340))
bytnamnknapp = knapp(gameDisplay, "Byt namn", (200, 440))

try:
    fil = open(".data/Namn", "r")
    namn = fil.read()
    fil.close()
except FileNotFoundError:
    namn = pygame_input(gameDisplay, "Vad heter du? ")
    fil = open(".data/Namn", "w")
    fil.write(namn)
    fil.close()

while 1:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if bytnamnknapp.ar_aktiv():
                namn = pygame_input(gameDisplay, "Vad heter du? ")
                fil = open(".data/Namn", "w")
                fil.write(namn)
                fil.close()
            if singleknapp.ar_aktiv():
                varldnamn = pygame_input(gameDisplay, "Namnge världen/Skriv din världs namn: ")
                while varldnamn.__contains__(",") or varldnamn.__contains__(";"):
                    varldnamn = pygame_input(gameDisplay, "Namnge världen/Skriv din världs namn: ")

                seed = ""
                try:
                    fil = open(".data/.världar/" + varldnamn + "/seed", "r")
                    fil.close()
                except FileNotFoundError:
                    seed = pygame_input(gameDisplay, "Skriv seed (enter för random): ")
                    while 1:
                        try:
                            if seed == "":
                                break
                            seed = int(seed)
                            break
                        except ValueError:
                            seed = pygame_input(gameDisplay, "Skriv seed (enter för random): ")

                start_new_thread(server, (varldnamn, False, seed))

                pygame.quit()

                klar = [False]
                start_new_thread(klient, (False, klar, pygame_input, namn))  # pygame_input är för att inte behöva definiera
                # den där också

                while 1:
                    time.sleep(5)
                    if klar[0]:
                        quit()

            if multiknapp.ar_aktiv():
                varldnamn = pygame_input(gameDisplay, "Namnge världen/Skriv din världs namn: ")
                while varldnamn.__contains__(",") or varldnamn.__contains__(";"):
                    varldnamn = pygame_input(gameDisplay, "Namnge världen/Skriv din världs namn: ")

                seed = ""
                try:
                    fil = open(".data/.världar/" + varldnamn + "/seed", "r")
                    fil.close()
                except FileNotFoundError:
                    seed = pygame_input(gameDisplay, "Skriv seed (enter för random): ")
                    while 1:
                        try:
                            if seed == "":
                                break
                            seed = int(seed)
                            break
                        except ValueError:
                            seed = pygame_input(gameDisplay, "Skriv seed (enter för random): ")

                start_new_thread(server, (varldnamn, True, seed))

                pygame.quit()

                klar = [False]
                start_new_thread(klient, (False, klar, pygame_input, namn))

                while 1:
                    time.sleep(5)
                    if klar[0]:
                        quit()

            if joinaknapp.ar_aktiv():
                pygame.quit()

                klar = [False]
                start_new_thread(klient, (True, klar, pygame_input, namn))

                while 1:
                    time.sleep(5)
                    if klar[0]:
                        quit()

    gameDisplay.fill((234, 56, 112))
    gameDisplay.blit(logga, (0, 0))
    singleknapp.rita()
    multiknapp.rita()
    joinaknapp.rita()
    bytnamnknapp.rita()

    pygame.display.update()
