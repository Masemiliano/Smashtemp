from classes import *  # för pycharms skull, är egentligen i program.py


def server(varldnamn, multi=True, setseed=""):
    global allapers, meddelanden, dagnum, dagnum, globalupdate, dagnum
    import os
    import random
    import socket
    import time
    from _thread import start_new_thread
    import global_vars

    global_vars.varldnamn = varldnamn

    try:
        os.mkdir(".data/.världar/" + global_vars.varldnamn)
        os.mkdir(".data/.världar/" + global_vars.varldnamn + "/värld")
        print("Skapade en ny värld med namnet " + str(global_vars.varldnamn) + ".")

        if setseed == "":
            global_vars.seed = random.randint(-1000000000, 1000000000)
        else:
            global_vars.seed = setseed
        print("Seedet " + str(global_vars.seed) + " användes.")
        seedfil = open(".data/.världar/" + str(global_vars.varldnamn) + "/seed", "w")
        seedfil.write(str(global_vars.seed))
        seedfil.close()

    except FileExistsError:
        print("Laddade in den befintliga världen " + str(global_vars.varldnamn) + ".")
        seedfil = open(".data/.världar/" + str(global_vars.varldnamn) + "/seed", "r")
        global_vars.seed = int(seedfil.read().strip())
        seedfil.close()

    ############################## fakta (-fel) ##############################
    hallrot = [None, 90, -90, 0, 180]
    hallplus = [None, (-56, 20), (94, 20), (20, -50), (20, 90)]  # de små ändringarna är pga bildens ojämnhet
    vaxter = ["ohlyt", "weclurt", "ebux", "spuqav", "svokli", "knecas", "oxlurt", "uilo", "weclurtmos", "ohlytmos",
              "svokliplanta", "odlad svokli", "glido", "hal", "kalepo"]
    utsattbara = ["weclurtmos", "ohlytmos", "svokliplanta", "uilo", "knecas", "glido", "oxlurt", "kalepo"]
    ohuggbara = ["uilo", "svokliplanta", "hal"]
    impassable = ["hal"]
    vaxtstorlekar = global_vars.vaxtstorlekar
    delfarger = [(56, 78, 32), (56, 78, 98), (140, 21, 12), (89, 89, 230), (67, 89, 150)]  # ska kanske användas

    ############################## settings ##############################
    global_vars.render_distance = 1
    delarssize = 700

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    s.bind(("", 5555))
    s.listen(100)

    def serverns_rakningar(_):
        global dagnum
        while 1:
            time.sleep(1 / 60)
            if allapers:
                dagnum += 1
                if dagnum > 18000:
                    dagnum = 0
                if dagnum % 200 == 0:
                    fil = open(".data/.världar/" + global_vars.varldnamn + "/dagnum", "w")
                    fil.write(str(dagnum))
                    fil.close()

    def nydelkanske(pos, hall, dardel, darpos, extraplus=(0, 0)):
        x, y = pos[0], pos[1]
        if x + hallplus[hall][0] + extraplus[0] > delarssize:
            dardel[0] += 1
            darpos[0] -= delarssize
        if x + hallplus[hall][0] + extraplus[0] < 0:
            dardel[0] -= 1
            darpos[0] += delarssize
        if y + hallplus[hall][1] + extraplus[1] > delarssize:
            dardel[1] += 1
            darpos[1] -= delarssize
        if y + hallplus[hall][1] + extraplus[1] < 0:
            dardel[1] -= 1
            darpos[1] += delarssize

    def lagg_till(delen, typ, pos, data=None):
        forefil = open(".data/.världar/" + global_vars.varldnamn + "/värld/" + str(delen[0]) + "u" + str(delen[1]),
                       "rb")
        fore = pickle.load(forefil)
        forefil.close()
        fore.entiteter.append(entitet((int(pos[0]), int(pos[1])), typ, data, False))
        efterfil = open(".data/.världar/" + global_vars.varldnamn + "/värld/" + str(delen[0]) + "u" + str(delen[1]),
                        "wb")
        pickle.dump(fore, efterfil)
        efterfil.close()

    def ta_bort_pa(pos, delen):
        forefil = open(".data/.världar/" + global_vars.varldnamn + "/värld/" + str(delen[0]) + "u" + str(delen[1]),
                       "rb")
        fore = pickle.load(forefil)
        forefil.close()
        num = 0
        den, original = None, None
        for v in fore.entiteter:
            if v.pos[0] + vaxtstorlekar[v.typ][0] > pos[0] > v.pos[0] - 1:
                if v.pos[1] + vaxtstorlekar[v.typ][1] > pos[1] > v.pos[1] - 1:
                    if vaxter[v.typ] not in ohuggbara:
                        den, original = v.typ, v.og
                        fore.entiteter.pop(num)
                        break
            num += 1
        if den is not None:
            efterfil = open(".data/.världar/" + global_vars.varldnamn + "/värld/" + str(delen[0]) + "u" + str(delen[1]),
                            "wb")
            pickle.dump(fore, efterfil)
            efterfil.close()
        return den, original

    def uilo_in(pos, delen, sattai):
        forefil = open(".data/.världar/" + global_vars.varldnamn + "/värld/" + str(delen[0]) + "u" + str(delen[1]),
                       "rb")
        fore = pickle.load(forefil)
        forefil.close()
        num = 0
        vilken = None
        den = None
        for v in fore.entiteter:
            if v.pos[0] + vaxtstorlekar[v.typ][0] > pos[0] > v.pos[0] - 1:
                if v.pos[1] + vaxtstorlekar[v.typ][1] > pos[1] > v.pos[1] - 1:
                    den = v.typ
                    vilken = num
                    break
            num += 1
        if den is not None and vaxter[den] == "uilo":
            fore.entiteter[vilken].data.append(sattai)
            efterfil = open(".data/.världar/" + global_vars.varldnamn + "/värld/" + str(delen[0]) + "u" + str(delen[1]),
                            "wb")
            pickle.dump(fore, efterfil)
            efterfil.close()
            return True

    def uilo_ut(pos, delen):
        forefil = open(".data/.världar/" + global_vars.varldnamn + "/värld/" + str(delen[0]) + "u" + str(delen[1]),
                       "rb")
        fore = pickle.load(forefil)
        forefil.close()
        num = 0
        vilken = None
        den = None
        for v in fore.entiteter:
            if v.pos[0] + vaxtstorlekar[v.typ][0] > pos[0] > v.pos[0] - 1:
                if v.pos[1] + vaxtstorlekar[v.typ][1] > pos[1] > v.pos[1] - 1:
                    den = v.typ
                    vilken = num
                    break
            num += 1
        if den is not None and vaxter[den] == "uilo":
            if fore.entiteter[vilken].data:
                tebaks = random.choice(fore.entiteter[vilken].data)
                fore.entiteter[vilken].data.pop(fore.entiteter[vilken].data.index(tebaks))
                efterfil = open(
                    ".data/.världar/" + global_vars.varldnamn + "/värld/" + str(delen[0]) + "u" + str(delen[1]),
                    "wb")
                pickle.dump(fore, efterfil)
                efterfil.close()
                return tebaks

    def nagot_check(vad, pos, delen, delovarmed=False):
        forefil = open(".data/.världar/" + global_vars.varldnamn + "/värld/" + str(delen[0]) + "u" + str(delen[1]),
                       "rb")
        fore = pickle.load(forefil)
        forefil.close()
        num = 0
        den = None
        v = None
        for v in fore.entiteter:
            if v.pos[0] + vaxtstorlekar[v.typ][0] > pos[0] > v.pos[0] - 1:
                if v.pos[1] + vaxtstorlekar[v.typ][1] > pos[1] > v.pos[1] - 1:
                    if vaxter[v.typ] == vad:
                        den = v.typ
                        break
            num += 1
        if den is not None and vaxter[den] == vad:
            if delovarmed:
                return True, delen, v
            else:
                return True
        else:
            if delovarmed:
                return None, None, None
            else:
                return None

    def smasha(vad):
        if vad == "weclurt":
            return "weclurtmos"
        elif vad == "ohlyt":
            return "ohlytmos"
        elif vad == "svokli":
            if random.randint(1, 17) == 1:
                return "svokliplanta"
            else:
                return "H+" + str(random.randint(1, 3))
        elif vad == "spuqav":
            return "glido*3"

    def client(c, a):
        global meddelanden, globalupdate
        namn = "okänd"
        try:
            if True:
                ############################## variabler ##############################
                ensdel, x, y = [0, 0], 100, 100
                delarrunt = []
                forra_delen = None
                hall = 1
                ryggsack = []
                i_handen = None
                hugg = 10
                i_sacken = False
                sackmarkerad = 0
                forradag = False
                smashmeny = False
                menymarkerad = 0
                antalalternativ = 3
                finnsuilo = False

                c.sendall(("Välkommen till servern " + global_vars.varldnamn + ".§Smashtemp 2§Oxlurt").encode())
                namn = c.recv(1024).decode()

                if namn in allapers or namn == "" or namn == " " or namn == "." or namn == "-" or namn == "  " or namn \
                        == "," or namn.strip() == "" or namn.__contains__(","):
                    print(str(a) + " försökte döpa sig till ett otillåtet namn eller namnet fanns redan.")
                    c.sendall("namnet".encode())
                    c.close()
                    return

                c.sendall('svilq,ohlyt,weclurt,ebux,spuqav,svokli,knecas,oxlurt,uilo,weclurtmos,ohlytmos,svokliplanta,'
                          'odlad svokli,glido,hal,kalepo,halner,under,kryss,'
                          'hugg'.encode())
                c.recv(1024)

                if multi:
                    print(namn + " är nu med och spelar!")

                meddelanden.insert(0, namn + " anslöt.")
                if len(meddelanden) > 4:
                    meddelanden.pop(-1)

                allapers.append(namn)
                allapers.append((ensdel[0], ensdel[1], int(x), int(y)))

                ############################## sparad data ##############################
                try:
                    fil = open(".data/.världar/" + global_vars.varldnamn + "/" + namn + "pos", "r")
                    posdata = fil.read()
                    x, y = float(posdata.split(",")[0]), float(posdata.split(",")[1])
                    ensdel = [int(posdata.split(",")[2]), int(posdata.split(",")[3])]
                    fil.close()
                    fil = open(".data/.världar/" + global_vars.varldnamn + "/" + namn + "rucksack", "r")
                    ruckdata = fil.read()
                    fil.close()
                    if ruckdata.__contains__("loser"):
                        ryggsack = []
                    else:
                        ryggsack = ruckdata.split(", ")
                    fil = open(".data/.världar/" + global_vars.varldnamn + "/" + namn + "hugg", "r")
                    hugg = int(fil.read().strip())
                    fil.close()
                    fil = open(".data/.världar/" + global_vars.varldnamn + "/" + namn + "handen", "r")
                    i_handen = fil.read().strip()
                    if i_handen == "None":
                        i_handen = None
                    fil.close()
                except FileNotFoundError:
                    pass

                speed = 1  # mindre är mer

                anpassad_speed = 1  # den ökar om fps:en är låg, så att man fortfarande rör sig lika snabbt

                update = True

                tid_i_borjan = time.time()

                trackobjekt, senare = [], []
                forrapos = (0, 0)

                while 1:
                    if globalupdate:
                        if globalupdate.__contains__(namn):
                            globalupdate.pop(globalupdate.index(namn) + 1)
                            globalupdate.pop(globalupdate.index(namn))
                            update = True

                    if x > delarssize:
                        x = 0
                        ensdel[0] += 1
                    if x < 0:
                        x = delarssize
                        ensdel[0] -= 1
                    if y > delarssize:
                        y = 0
                        ensdel[1] += 1
                    if y < 0:
                        y = delarssize
                        ensdel[1] -= 1

                    if update or globalupdate or ensdel != forra_delen:  # den laddar bara om man är i en ny del
                        delarrunt = ladda(ensdel, delarssize).copy()
                        forra_delen = ensdel.copy()

                    extraljust = False

                    ##############################################################################################
                    ##############################################################################################
                    ##############################################################################################
                    # allt skaskicka
                    if dagnum > 12000:
                        skaskicka = "F:243:67:159,0,0;"
                        forradag = True
                        extraljust = True
                    else:
                        skaskicka = "F:243:67:159,0,0;"
                        if forradag:
                            hugg += 5
                        forradag = False

                    # växterna och bakgrunden
                    if (x, y) != forrapos or update:
                        trackobjekt, senare = [], []
                        update = False
                        forrapos = (x, y)

                        if False:
                            # den loopar två gånger eftersom plantorna inte ska skäras av mellan delar
                            xph, yph = -delarssize * global_vars.render_distance - int(x) + 480, -delarssize * global_vars.\
                                render_distance - int(y) + 280
                            tempnum = 0
                            for v in delarrunt:
                                if -700 <= xph <= 1000 and -700 <= yph <= 600:
                                    trackobjekt.append(str(-4 - v.typ) + "," + str(xph) + "," + str(yph))
                                xph += delarssize
                                tempnum += 1
                                if tempnum > global_vars.render_distance * 2 + 1:
                                    xph = -delarssize * global_vars.render_distance - int(x) + 480
                                    yph += delarssize
                                    tempnum = 0

                        xph, yph = -delarssize * global_vars.render_distance - int(x) + 480, -delarssize * global_vars.\
                            render_distance - int(y) + 280
                        tempnum = 0
                        for v in delarrunt:
                            for v2 in v.entiteter:
                                if -vaxtstorlekar[v2.typ][0] < xph + v2.pos[0] < 1000 and \
                                        -vaxtstorlekar[v2.typ][1] < yph + v2.pos[1] < 600:
                                    if vaxter[v2.typ] == "glido":
                                        #                       + 1 för att bilden på personer, svilq, är först
                                        trackobjekt.append(str(v2.typ + 1) + "," + str(xph + v2.pos[0]) + "," + str(
                                            yph + v2.pos[1]))
                                    elif vaxter[v2.typ] == "kalepo":
                                        senare.append(str(v2.typ + 1) + "," + str(xph + v2.pos[0]) + "," + str(
                                            yph + v2.pos[1]))
                                        senare.append("T:" + v2.data[0] + "," + str(xph + v2.pos[0]) + "," + str(
                                            yph + v2.pos[1]))
                                    else:
                                        senare.append(str(v2.typ + 1) + "," + str(xph + v2.pos[0]) + "," + str(
                                            yph + v2.pos[1]))
                            xph += delarssize
                            tempnum += 1
                            if tempnum > global_vars.render_distance * 2 + 1:
                                xph = -delarssize * global_vars.render_distance - int(x) + 480
                                yph += delarssize
                                tempnum = 0

                    for v in trackobjekt:
                        skaskicka += v + ";"

                    skaskicka += "0i,480,280," + str(hallrot[hall]) + ",1;"

                    # just dont ask about this shit and dont try to understand it i wont explain how it work
                    allapers[allapers.index(namn) + 1] = (ensdel[0], ensdel[1], int(x), int(y))
                    for num in range(0, len(allapers), 2):
                        if allapers[num] != namn:
                            if ensdel[0] - global_vars.render_distance <= allapers[num + 1][0] <= ensdel[0] + \
                                    global_vars.render_distance:
                                if ensdel[1] - global_vars.render_distance <= allapers[num + 1][1] <= ensdel[1] + \
                                        global_vars.render_distance:
                                    ett, tva = str(delarssize * (allapers[num + 1][0] - ensdel[0]) -
                                                   int(x) + allapers[
                                                       num + 1][2] + 480), str(
                                        delarssize * (allapers[num + 1][1] - ensdel[1]) - int(y) + allapers[
                                            num + 1][3] + 280)
                                    skaskicka += "0," + ett + "," + tva + ";"
                                    skaskicka += "T:" + str(allapers[num]) + "," + ett + "," + tva + ";"

                    for v in senare:
                        skaskicka += v + ";"

                    if skaskicka != "inget":
                        if skaskicka:
                            if i_handen is not None:
                                extrafix = (-int(vaxtstorlekar[vaxter.index(i_handen)][0] / 2 * 0.3), -int(
                                    vaxtstorlekar[vaxter.index(i_handen)][1] / 2 * 0.3))
                                skaskicka += str(vaxter.index(i_handen) + 1) + "," + str(
                                    480 + hallplus[hall][0] + extrafix[0]) + "," + str(
                                    280 + hallplus[hall][1] + extrafix[1]) + ",0,0.3"  # minibilden

                            if extraljust:
                                skaskicka += ";extra_ljust,0,0"

                            skaskicka += ";-2i," + str(480 + hallplus[hall][0]) + "," + str(
                                280 + hallplus[hall][1])  # krysset

                            skaskicka += ";T: " + str(ensdel[0]) + "§" + str(ensdel[1]) + "*" + str(int(x)) + "§" + str(
                                int(y)) + ",850,0"  # koordinaterna
                            skaskicka += ";T: Hugg: " + str(hugg) + ",30,0;-1i,0,0"  # hugg kvar

                            yh = 560
                            for m in meddelanden:
                                skaskicka += ";T: " + m + ",0," + str(yh)
                                yh -= 30

                            if i_sacken and not smashmeny:
                                skaskicka += ";F:45:67:87:100:100:800:400,0,0"
                                # de två sista spelar noll roll när man fillar, men måste dit

                                xh, yh = 120, 120
                                num = 0
                                for v in ryggsack:
                                    if num == sackmarkerad:
                                        skaskicka += ";F:0:255:0:" + str(xh) + ":" + str(yh + 24) + ":" + str(
                                            get_textwidth(
                                                v, 30)) + ":3,0,0"
                                    skaskicka += ";T:" + v + "," + str(xh) + "," + str(yh)
                                    skaskicka += ";" + str(vaxter.index(v) + 1) + "," + str(xh + 90) + "," + str(
                                        yh) + ",0,0.2"
                                    xh += 170
                                    if xh > 700:
                                        xh = 120
                                        yh += 50
                                    num += 1
                                if i_handen is not None:
                                    skaskicka += ";T:I handen: " + str(i_handen) + ",330,470"
                            elif smashmeny:
                                skaskicka += ";F:45:67:87:100:100:800:400,0,0"
                                skaskicka += ";T:Avbryt,160,120;T:Sätt i handen,160,180;T:Smasha,160," \
                                             "240;T:Gruppsmasha,160,300 "
                                skaskicka += ";F:0:255:0:145:" + str(120 + 60 * menymarkerad) + ":5:10,0,0"
                                if finnsuilo:
                                    skaskicka += ";T:Sätt ner i uilon,160,360;T:Ta upp något ur uilon,160,420"
                        else:
                            skaskicka = "inget"

                    skaskicka = skaskicka.replace(";;", ";")  # för att förhindra onödig dataöverföring

                    c.sendall(skaskicka.encode())

                    mottaget = c.recv(256).decode()

                    dettog = time.time() - tid_i_borjan
                    anpassad_speed = 60 / (speed / (dettog + 0.00000000001))
                    tid_i_borjan = time.time()

                    if mottaget != "inget":
                        events = mottaget.split("+")

                        xp, yp = 0, 0
                        if events.__contains__("left"):
                            if not i_sacken:
                                xp = -anpassad_speed
                                hall = 1
                        if events.__contains__("right"):
                            if not i_sacken:
                                xp = anpassad_speed
                                hall = 2
                        if events.__contains__("up"):
                            if not i_sacken:
                                yp = -anpassad_speed
                                hall = 3
                        if events.__contains__("down"):
                            if not i_sacken:
                                yp = anpassad_speed
                                hall = 4

                        if xp or yp:
                            # Den gör två loopar, en där den checkar efter transporthjälpmedel och en annan där den
                            # kollar efter stoppar. Det är pga att den måste veta hur snabbt den far före den kan veta
                            # om den krockar.

                            snabbt = False
                            xph, yph = -delarssize * global_vars.render_distance - int(
                                x) + 480, -delarssize * global_vars. \
                                           render_distance - int(y) + 280
                            tempnum = 0
                            for v in delarrunt:
                                for v2 in v.entiteter:
                                    if vaxter[v2.typ] == "glido":
                                        if -200 < xph + v2.pos[0] < 1000 and -200 < yph + v2.pos[1] < 600:
                                            if 480 < xph + v2.pos[0] < 520 or xph + v2.pos[0] < 480 < xph + \
                                                    v2.pos[0] + 100:
                                                if 280 < yph + v2.pos[1] < 320 or yph + v2.pos[1] < 280 < \
                                                        yph + v2.pos[1] + 100:
                                                    snabbt = True
                                                    xp, yp = xp * 3, yp * 3
                                                    break
                                if snabbt:
                                    break
                                xph += delarssize
                                tempnum += 1
                                if tempnum > global_vars.render_distance * 2 + 1:
                                    xph = -delarssize * global_vars.render_distance - int(x) + 480
                                    yph += delarssize
                                    tempnum = 0

                            garej = False
                            xph, yph = -delarssize * global_vars.render_distance - int(
                                x) + 480, -delarssize * global_vars.\
                                render_distance - int(y) + 280
                            tempnum = 0
                            for v in delarrunt:
                                for v2 in v.entiteter:
                                    if vaxter[v2.typ] in impassable:
                                        xet, yet = vaxtstorlekar[v2.typ]
                                        if -200 < xph + v2.pos[0] < 1000 and -200 < yph + v2.pos[1] < 600:
                                            if 480 + xp < xph + v2.pos[0] < 520 + xp or xph + v2.pos[0] < 480 + xp < \
                                                    xph + v2.pos[0] + xet:
                                                if 280 + yp < yph + v2.pos[1] < 320 + yp or yph + v2.pos[1] < 280 + yp \
                                                        < yph + v2.pos[1] + yet:
                                                    garej = True
                                if garej:
                                    break
                                xph += delarssize
                                tempnum += 1
                                if tempnum > global_vars.render_distance * 2 + 1:
                                    xph = -delarssize * global_vars.render_distance - int(x) + 480
                                    yph += delarssize
                                    tempnum = 0

                            if not garej:
                                x += xp
                                y += yp

                        if events.__contains__("kd_space"):
                            dardel, darpos = ensdel.copy(), [x + hallplus[hall][0], y + hallplus[hall][1]]
                            nydelkanske((x, y), hall, dardel, darpos)
                            finnshal = nagot_check("hal", darpos, dardel, True)
                            if finnshal[0] is None:
                                finnshal = nagot_check("hal", (darpos[0] + delarssize, darpos[1]), (
                                    dardel[0] - 1, dardel[1]), True)
                                if finnshal[0] is None:
                                    finnshal = nagot_check("hal", (darpos[0], darpos[1] + delarssize),
                                                           (dardel[0], dardel[1] - 1), True)
                                    if finnshal[0] is None:
                                        finnshal = nagot_check("hal", (darpos[0] + delarssize, darpos[
                                            1] + delarssize), (dardel[0] - 1, dardel[1] - 1), True)
                            if finnshal[0]:
                                nere = True
                                djup = 1
                                bunkerx, bunkery = 420, 480
                                while nere:
                                    stalle = str(finnshal[1][0]) + "u" + str(finnshal[1][1]) + "u" + str(djup)

                                    try:
                                        fil = open(".data/.världar/" + varldnamn + "/värld/hål" + stalle, "r")
                                        data = fil.read().strip().split(";")
                                        fil.close()
                                    except FileNotFoundError:
                                        data = []
                                        fil = open(".data/.världar/" + varldnamn + "/värld/hål" + stalle, "w")
                                        fil.close()

                                    while 1:
                                        dettog = time.time() - tid_i_borjan
                                        anpassad_speed = 60 / (speed / (dettog + 0.00000000001))
                                        tid_i_borjan = time.time()

                                        sendhar = "-3,0,0;"
                                        if finnshal[2].data[0] > djup:
                                            sendhar += "-4,370,110;"
                                        sendhar += "0," + str(int(bunkerx)) + "," + str(int(bunkery))

                                        for v in data:
                                            if v:
                                                sendhar += ";" + v

                                        sendhar += ";T:Djup: " + str(djup) + ",5,5"

                                        c.sendall(sendhar.encode())

                                        mothar = c.recv(1024).decode()

                                        if mothar != "inget":
                                            eventshar = mothar.split("+")
                                            if eventshar.__contains__("kd_space"):
                                                if bunkery > 400 and 360 < bunkerx < 483:
                                                    djup -= 1
                                                    bunkerx, bunkery = 426, 120
                                                    if djup == 0:
                                                        nere = False
                                                    break
                                                if bunkery < 180 and 355 < bunkerx < 490:
                                                    if djup < finnshal[2].data[0]:
                                                        djup += 1
                                                        bunkerx, bunkery = 420, 480
                                                        break
                                            bxp, byp = 0, 0
                                            if eventshar.__contains__("left"):
                                                bxp = -anpassad_speed * 2
                                            if eventshar.__contains__("right"):
                                                bxp = anpassad_speed * 2
                                            if eventshar.__contains__("up"):
                                                byp = -anpassad_speed * 2
                                            if eventshar.__contains__("down"):
                                                byp = anpassad_speed * 2
                                            if bxp or byp:
                                                if 100 <= bunkerx + bxp < 840:
                                                    bunkerx += bxp
                                                if 100 <= bunkery + byp < 490:
                                                    bunkery += byp

                                            if eventshar.__contains__("kd_t") and i_handen is not None:
                                                if len(ryggsack) < 24:
                                                    ryggsack.append(i_handen)
                                                    i_handen = None
                                            if eventshar.__contains__("kd_v") and i_handen is not None:
                                                if i_handen != "uilo":
                                                    data.append(str(vaxter.index(
                                                        i_handen) + 1) + "," + str(int(bunkerx)) + "," + str(
                                                        int(bunkery)))
                                                    fil = open(
                                                        ".data/.världar/" + varldnamn + "/värld/hål" + stalle, "a")
                                                    fil.write(str(vaxter.index(i_handen) + 1) + "," + str(
                                                        int(bunkerx)) + "," + str(int(bunkery)) + ";")
                                                    fil.close()
                                                    if ryggsack.__contains__(i_handen):
                                                        ryggsack.pop(ryggsack.index(i_handen))
                                                    else:
                                                        i_handen = None
                                            if eventshar.__contains__("kd_x"):
                                                if len(ryggsack) < 24:
                                                    num, ja = 0, False
                                                    for v in data:
                                                        if v:
                                                            d = int(v.split(",")[0]), int(v.split(",")[1]), int(v.split(
                                                                ",")[2])
                                                            if d[1] <= bunkerx <= d[1] + \
                                                                    global_vars.vaxtstorlekar[d[0] - 1][0] \
                                                                    or bunkerx <= d[1] <= bunkerx + 40:
                                                                if d[2] <= bunkery <= d[2] + \
                                                                        global_vars.vaxtstorlekar[d[0] - 1][1] or \
                                                                        bunkery <= d[2] <= bunkery + 40:
                                                                    ryggsack.append(vaxter[d[0] - 1])
                                                                    data.pop(num)
                                                                    ja = True
                                                                    break
                                                        num += 1
                                                    if ja:
                                                        fil = open(
                                                            ".data/.världar/" + varldnamn + "/värld/hål" + stalle, "w")
                                                        for v in data:
                                                            fil.write(v + ";")
                                                        fil.close()
                        if events.__contains__("kd_return"):
                            if smashmeny:
                                smashmeny = False
                                if menymarkerad == 1:
                                    # detta är en dublett! kd_h också
                                    if i_sacken:
                                        if i_handen is not None:
                                            ryggsack.append(i_handen)
                                        i_handen = ryggsack[sackmarkerad]
                                        ryggsack.pop(sackmarkerad)
                                        sackmarkerad = 0
                                if menymarkerad == 2:
                                    if i_sacken:  # borde vara onödigt? Man kan väl inte vara i menyn men ej i säcken?
                                        dash = smasha(ryggsack[sackmarkerad])
                                        if dash is not None:
                                            if dash[:2] == "H+":
                                                hugg += int(dash[2:])
                                            elif dash.__contains__("*"):
                                                for _ in range(0, int(dash.split("*")[1])):
                                                    ryggsack.append(dash.split("*")[0])
                                            else:
                                                ryggsack.append(dash)
                                            ryggsack.pop(sackmarkerad)
                                            sackmarkerad = 0
                                if menymarkerad == 3:
                                    if i_sacken:  # borde väl vara onödigt? Man kan väl inte vara i menyn men ej i
                                        # säcken?
                                        if ryggsack[sackmarkerad] == "ebux":
                                            num = 0
                                            for v in ryggsack:
                                                if v == "ebux":
                                                    num += 1
                                            if num > 6:
                                                for _ in range(0, 7):
                                                    ryggsack.pop(ryggsack.index("ebux"))
                                                ryggsack.append("uilo")
                                        sackmarkerad = 0
                                if menymarkerad == 4:
                                    if finnsuilo and ryggsack:
                                        dardel, darpos = ensdel.copy(), [x + hallplus[hall][0], y + hallplus[hall][1]]
                                        # this fixes so that it checks from the cross and not the player
                                        nydelkanske((x, y), hall, dardel, darpos)
                                        hugget = uilo_in(darpos, dardel, ryggsack[sackmarkerad])
                                        # it makes a total of four checks, one normal, one to the left, one to the
                                        # up, one up and left this is because sometimes the kryss is over a växt that
                                        # is actually in the upper or right del och sticker bara ut in i den del
                                        # krysset är på
                                        if hugget is None:
                                            hugget = uilo_in((darpos[0] + delarssize, darpos[1]),
                                                             (dardel[0] - 1, dardel[1]), ryggsack[sackmarkerad])
                                            if hugget is None:
                                                hugget = uilo_in((darpos[0], darpos[1] + delarssize),
                                                                 (dardel[0], dardel[1] - 1), ryggsack[sackmarkerad])
                                                if hugget is None:
                                                    hugget = uilo_in((darpos[0] + delarssize, darpos[1] + delarssize),
                                                                     (dardel[0] - 1, dardel[1] - 1),
                                                                     ryggsack[sackmarkerad])
                                        if hugget:
                                            ryggsack.pop(sackmarkerad)
                                            sackmarkerad = 0
                                if menymarkerad == 5:
                                    if finnsuilo and i_sacken and (len(ryggsack) < 24 or i_handen is None):
                                        dardel, darpos = ensdel.copy(), [x + hallplus[hall][0], y + hallplus[hall][1]]
                                        # this fixes so that it checks from the cross and not the player
                                        nydelkanske((x, y), hall, dardel, darpos)
                                        uttaget = uilo_ut(darpos, dardel)
                                        # it makes a total of four checks, one normal, one to the left, one to the
                                        # up, one up and left this is because sometimes the kryss is over a växt that
                                        # is actually in the upper or right del och sticker bara ut in i den del
                                        # krysset är på
                                        if uttaget is None:
                                            uttaget = uilo_ut((darpos[0] + delarssize, darpos[1]), (
                                                dardel[0] - 1, dardel[1]))
                                            if uttaget is None:
                                                uttaget = uilo_ut((darpos[0], darpos[1] + delarssize),
                                                                  (dardel[0], dardel[1] - 1))
                                                if uttaget is None:
                                                    uttaget = uilo_ut((darpos[0] + delarssize, darpos[1] + delarssize),
                                                                      (dardel[0] - 1, dardel[1] - 1))
                                        if uttaget:
                                            if len(ryggsack) < 24:
                                                ryggsack.append(uttaget)
                                            else:
                                                i_handen = uttaget
                            elif i_sacken:
                                if len(ryggsack) > 0:
                                    antalalternativ = 3
                                    smashmeny = True
                                    menymarkerad = 0
                                    dardel, darpos = ensdel.copy(), [x + hallplus[hall][0], y + hallplus[hall][1]]
                                    nydelkanske((x, y), hall, dardel, darpos)
                                    finnsuilo = nagot_check("uilo", darpos, dardel)
                                    if finnsuilo is None:
                                        finnsuilo = nagot_check("uilo", (darpos[0] + delarssize, darpos[1]), (
                                            dardel[0] - 1, dardel[1]))
                                        if finnsuilo is None:
                                            finnsuilo = nagot_check("uilo", (darpos[0], darpos[1] + delarssize),
                                                                    (dardel[0], dardel[1] - 1))
                                            if finnsuilo is None:
                                                finnsuilo = nagot_check("uilo", (darpos[0] + delarssize, darpos[
                                                    1] + delarssize), (dardel[0] - 1, dardel[1] - 1))
                                    if finnsuilo:
                                        antalalternativ += 2

                        if events.__contains__("kd_s"):
                            if i_sacken and not smashmeny:
                                dash = smasha(ryggsack[sackmarkerad])
                                if dash is not None:
                                    if dash[:2] == "H+":
                                        hugg += int(dash[2:])
                                    elif dash.__contains__("*"):
                                        for _ in range(0, int(dash.split("*")[1])):
                                            ryggsack.append(dash.split("*")[0])
                                    else:
                                        ryggsack.append(dash)
                                    ryggsack.pop(sackmarkerad)
                                    sackmarkerad = 0
                        if events.__contains__("kd_left"):
                            if i_sacken and not smashmeny:
                                if sackmarkerad - 1 > -1:
                                    sackmarkerad -= 1
                        if events.__contains__("kd_right"):
                            if i_sacken and not smashmeny:
                                if sackmarkerad + 1 < len(ryggsack):
                                    sackmarkerad += 1
                        if events.__contains__("kd_up"):
                            if smashmeny:
                                if menymarkerad > 0:
                                    menymarkerad -= 1
                                else:
                                    menymarkerad = antalalternativ
                            elif i_sacken:
                                if sackmarkerad - 4 > -1:
                                    sackmarkerad -= 4
                        if events.__contains__("kd_down"):
                            if smashmeny:
                                if menymarkerad < antalalternativ:
                                    menymarkerad += 1
                                else:
                                    menymarkerad = 0
                            elif i_sacken:
                                if sackmarkerad + 4 < len(ryggsack):
                                    sackmarkerad += 4
                        if events.__contains__("kd_h"):
                            # detta är en dublett! kd_return och menymarkerad 1 också
                            if i_sacken:
                                if i_handen is not None:
                                    ryggsack.append(i_handen)
                                i_handen = ryggsack[sackmarkerad]
                                ryggsack.pop(sackmarkerad)
                                sackmarkerad = 0
                        if events.__contains__("kd_v") and not i_sacken:
                            if i_handen is not None and i_handen in utsattbara:

                                extrafix = (-int(vaxtstorlekar[vaxter.index(i_handen)][
                                                     0] / 2), -int(vaxtstorlekar[vaxter.index(i_handen)][1] / 2))

                                dardel = ensdel.copy()
                                darpos = [x + hallplus[hall][0] + extrafix[0], y + hallplus[hall][1] + extrafix[1]]
                                nydelkanske((x, y), hall, dardel, darpos, (extrafix[0], extrafix[1]))

                                if i_handen == "kalepo":
                                    c.sendall("input".encode())
                                    c.recv(1024)
                                    c.sendall("inget".encode())
                                    text = c.recv(1024).decode()[2:]
                                    lagg_till(dardel, vaxter.index(i_handen),
                                              darpos, [text])
                                else:
                                    lagg_till(dardel, vaxter.index(i_handen),
                                              darpos)
                                forra = i_handen
                                i_handen = None
                                for v in ryggsack:
                                    if v == forra:
                                        i_handen = v
                                        ryggsack.pop(ryggsack.index(v))
                                        break
                                update = True
                                globalupdate = allapers.copy()
                                globalupdate.pop(globalupdate.index(namn) + 1)
                                globalupdate.pop(globalupdate.index(namn))
                        if events.__contains__(
                                "kd_x") and not i_sacken:  # the shit under this is a bit complicated so just
                            # accept it working
                            # just kidding i'll explain it
                            if hugg > 0 and len(ryggsack) < 24:
                                dardel, darpos = ensdel.copy(), [x + hallplus[hall][0], y + hallplus[hall][1]]
                                # this fixes so that it checks from the cross and not the player
                                nydelkanske((x, y), hall, dardel, darpos)
                                hugget = ta_bort_pa(darpos, dardel)
                                # it makes a total of four checks, one normal, one to the left, one to the up,
                                # one up and left this is because sometimes the kryss is over a växt that is actually
                                # in the upper or right del och sticker bara ut in i den del krysset är på
                                if hugget[0] is None:
                                    hugget = ta_bort_pa((darpos[0] + delarssize, darpos[1]), (dardel[0] - 1, dardel[1]))
                                    if hugget[0] is None:
                                        hugget = ta_bort_pa((
                                            darpos[0], darpos[1] + delarssize), (dardel[0], dardel[1] - 1))
                                        if hugget[0] is None:
                                            hugget = ta_bort_pa((darpos[0] + delarssize, darpos[1] + delarssize),
                                                                (dardel[0] - 1, dardel[1] - 1))
                                if hugget[0] is not None:
                                    if hugget[1]:
                                        hugg -= 1
                                    update = True
                                    ryggsack.append(vaxter[hugget[0]])
                                    globalupdate = allapers.copy()
                                    globalupdate.pop(globalupdate.index(namn) + 1)
                                    globalupdate.pop(globalupdate.index(namn))
                        if events.__contains__("kd_r"):
                            if i_sacken:
                                i_sacken = False
                                smashmeny = False
                            else:
                                i_sacken = True
                                sackmarkerad = 0
                        elif events.__contains__("kd_t"):  # bara om man inte också trycker space
                            if i_sacken and i_handen is not None:
                                ryggsack.append(i_handen)
                                i_handen = None
                        for v in events:
                            if v[:2] == "M:":
                                if v[2:]:
                                    meddelanden.insert(0, namn + ": " + v[2:].replace(";", "½").replace(",", "§"))
                                if len(meddelanden) > 4:
                                    meddelanden.pop(-1)

        except Exception as e:
            print("\n" + namn + " avanslöt. (" + str(e) + ")")
            meddelanden.insert(0, namn + " avanslöt.")
            if len(meddelanden) > 4:
                meddelanden.pop(-1)
            allapers.pop(allapers.index(namn) + 1)
            allapers.pop(allapers.index(namn))

            try:
                fil = open(".data/.världar/" + global_vars.varldnamn + "/" + namn + "pos", "w")
                fil.write(str(x) + "," + str(y) + "," + str(ensdel[0]) + "," + str(ensdel[1]))
                fil.close()
                fil = open(".data/.världar/" + global_vars.varldnamn + "/" + namn + "rucksack", "w")
                if ryggsack:
                    fil.write(str(ryggsack).replace("[", "").replace("]", "").replace("'", ""))
                else:
                    fil.write("loser")
                fil.close()
                fil = open(".data/.världar/" + global_vars.varldnamn + "/" + namn + "hugg", "w")
                fil.write(str(hugg))
                fil.close()
                fil = open(".data/.världar/" + global_vars.varldnamn + "/" + namn + "handen", "w")
                fil.write(str(i_handen))
                fil.close()
            except Exception as e:
                print("\nOkänd person kickades direkt (" + str(e) + ").")

    allapers = []
    meddelanden = ["Välkommen till servern " + global_vars.varldnamn + "!"]
    dagnum = 0
    globalupdate = []

    try:
        filu = open(".data/.världar/" + global_vars.varldnamn + "/dagnum", "r")
        dagnum = int(filu.read().strip())
        filu.close()
    except FileNotFoundError:
        pass

    start_new_thread(serverns_rakningar, (0,))

    if multi:
        print("\nServern har startat.")
        print("\nVäntar på anslutningar...")

        while 1:
            conn, addr = s.accept()
            start_new_thread(client, (conn, addr))
            print("\n" + str(addr) + " anslöt.")
    else:
        conn, addr = s.accept()
        start_new_thread(client, (conn, addr))
        while 1:
            time.sleep(400)

# server(input("Skriv namnet på din värld eller namnge en ny värld: "), True)
