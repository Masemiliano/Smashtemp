def client(stopp, ip):
    import pygame
    import socket
    from _thread import start_new_thread
    import os
    from classes import skriv, get_textsize, vaxtlista, vaxtsizes, blitta_under, pygame_input, playersize
    import random

    pygame.init()

    class cliententitet:
        def __init__(self, pos, typ):
            self.pos = pos
            self.typ = typ

    class clientdel:
        def __init__(self):
            self.entiteter = []
            self.miljo = 0

    port = 5555

    c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    c.connect((ip, port))

    try:
        fil = open(".data/Playerdata", "r")
        spelardata = fil.read()
        namn = spelardata.split("\n")[0]
        playertype = int(spelardata.split("\n")[1])
        fil.close()
    except FileNotFoundError:
        namn = input("Vad vill du kallas? ")
        playertype = 0
        fil = open(".data/Playerdata", "w")
        fil.write(namn + "\n" + str(playertype))
        fil.close()

    c.sendall(namn.encode())

    def fixa_ryggsacksbilden(vald=0):
        ryggsackbild.fill((45, 67, 87))
        xh, yh = 30, 30
        num = 0
        for r in ryggsack:
            ryggsackbild.blit(pygame.transform.scale(bilder[bildlista.index(r + "bild")], (30, 30)), (xh, yh))
            skriv(ryggsackbild, r, (xh + 40, yh))
            if num == vald:
                ryggsackbild.fill((0, 255, 0), (xh + 40, yh + 20, get_textsize(r, 30)[0], 3))

            xh += 155
            if (num + 1) % 5 == 0:
                yh += 60
                xh = 30

            num += 1

    def cinect(_):  # connectionen med servern
        nonlocal delar, x, y, order, xn, yn, update, ensdel, forradel, spelare, ryggsackoppen, ryggsack, ryggsackbild, \
            handen, rvald, serverns_hastighetsorder, hugg, dagtid

        while True:
            if stopp[0]:
                quit()

            mottaget = c.recv(4096).decode()

            data = mottaget.split("¤")

            for kommando in data:
                if kommando[:2] == "D:":  # del eller data

                    delar = []
                    deldataor = kommando.split("/")[0].split("%")
                    deldataor.pop(0)
                    for v in deldataor:
                        ny_del = clientdel()
                        ny_del.miljo = int(v[0])

                        if v.__contains__(":"):
                            datapieces = v.split(":")
                            datapieces.pop(0)

                            for vh in datapieces:
                                if vh:
                                    pos = (int(vh.split(",")[1].split(".")[0]), int(vh.split(",")[1].split(".")[1]))
                                    typ = int(vh.split(",")[0])
                                    ny_del.entiteter.append(cliententitet(pos, typ))

                        delar.append(ny_del)

                    # den har transparent på sig och måste därför fyllas så att de gamla växterna inte är kvar
                    entladdbild.fill((255, 255, 255, 0))

                    delnum = 0
                    for v in delar:
                        specpos = (blitting[delnum][0] + 700, blitting[delnum][1] + 700)
                        bakladdbild.blit(bilder[bildlista.index("bakgrund" + str(v.miljo) + "bild")], specpos)

                        delnum += 1

                    delnum = 0
                    for v in delar:
                        for v2 in v.entiteter:
                            specpos = (blitting[delnum][0] + v2.pos[0] + 700, blitting[delnum][1] + v2.pos[1] + 700)
                            if blitta_under.__contains__(vaxtlista[v2.typ]):
                                bakladdbild.blit(bilder[bildlista.index(vaxtlista[v2.typ] + "bild")], specpos)
                            else:
                                entladdbild.blit(bilder[bildlista.index(vaxtlista[v2.typ] + "bild")], specpos)

                        delnum += 1

                    forradel = ensdel.copy()
                    xn, yn, ensdel = int(kommando.split("/")[1][2:].split(",")[0]), int(kommando.split("/")[1][2:].
                                                                                        split(",")[1]), [
                                         int(kommando.split("/")[1][2:].split(",")[2]),
                                         int(kommando.split("/")[1][2:].split(",")[3])]
                    update = True  # fixar så att rit-threadet inte hinner rita förrän x och y är uppdaterade

                if kommando[:2] == "R:":
                    r = kommando[3:].split(":")[0]
                    h = kommando[3:].split(":")[1]
                    hugg = int(kommando[3:].split(":")[2])

                    if h == "n":
                        handen = None
                    else:
                        handen = vaxtlista[int(h)]

                    if kommando[2] == "1":
                        rvald = 0
                        ryggsackoppen = not ryggsackoppen

                    if r:
                        rd = r.split("/")
                        ryggsack = []
                        for v in rd:
                            ryggsack.append(vaxtlista[int(v)])
                    else:
                        ryggsack = []

                    if ryggsackoppen:
                        fixa_ryggsacksbilden(rvald)

                if kommando[:2] == "S:":  # spelare
                    spelare = []
                    for v in kommando[2:].split(":"):
                        spelare.append((v.split(",")[0], int(v.split(",")[1]), int(
                            v.split(",")[2]), int(v.split(",")[3]), int(v.split(",")[4]), int(v.split(",")[5]),
                                        int(v.split(",")[6])))
                if kommando == "S":  # klienten kan få som info att det inte finns några spelare runt den
                    spelare = []
                if kommando[:2] == "H:":
                    serverns_hastighetsorder = int(kommando[2:])
                if kommando[:2] == "c:":
                    for v in kommando[2:].split("\n"):
                        chatt.append(v)

                if kommando == "exit":
                    stopp[0] = True

                if kommando[:2] == "T:":
                    dagtid = int(kommando[2])

            if update:  # om rit-threadet inte fattat att x och y uppdaterats så skickar detta threadet ändå de nya
                # uppdaterade koordinaterna
                skicka = str(int(xn)) + "," + str(int(yn)) + "," + str(hall)
            else:
                skicka = str(int(x)) + "," + str(int(y)) + "," + str(hall)

            skicka += "+"
            for vh in order:
                skicka += vh + "¤"
            order = []

            if not skicka[-1] == "+":  # om inga order skickas måste ändå plusset vara kvar pga splittingen i servern
                skicka = skicka[:-1]

            c.sendall(skicka.encode())

    delar = []
    ensdel = [0, 0]
    forradel = [0, 0]
    x, y = 100, 100
    xn, yn = 100, 100  # när den uppdaterar behöver x, y och laddbild uppdateras i rit-threadet. Därför sätter socket-
    # threadet 'update' till True och uppdaterar temporära variabler som sen rit-threadet tar åt sig.
    hall = 0
    order = ["rw"]

    ryggsackoppen = False
    ryggsack = []
    ryggsackbild = pygame.Surface((800, 400))
    rvald = 0  # ryggsäcksvald
    serverns_hastighetsorder = 60

    chatt = []
    hugg = 10

    dagtid = 0

    # waitaminute = True # den användes till att uppdatera ryggsäcken utan att gå ut ur den. Om denna är True så gås
    # inte ryggsäcken ut ur/in i vid nästa uppdatering

    fordata = c.recv(1024).decode()

    posar = fordata.split(":")[0]

    handen = fordata.split(":")[1]
    if handen == "None":
        handen = None

    x, y = int(posar.split(",")[0]), int(posar.split(",")[1])
    xn, yn = int(posar.split(",")[0]), int(posar.split(",")[1])
    ensdel = [int(posar.split(",")[2]), int(posar.split(",")[3])]
    forradel = [int(posar.split(",")[2]), int(posar.split(",")[3])]

    c.send(str(playertype).encode())

    bot = False

    update = False

    blitting = [(-700, -700), (0, -700), (700, -700), (-700, 0), (0, 0), (700, 0), (-700, 700), (0, 700), (700, 700)]

    # nu ser det confusing ut, förut var det bara siffror. Detta gjordes om så att krysset blir på mitten av gubben, hur
    # stor den än är. Inte för att det playersizen planeras att ändras, men ändå
    krysspos = [(playersize[0] / 2, -40), (-40, playersize[1] / 2), (
        playersize[0] / 2, 70), (70, playersize[1] / 2)]

    entiteterbild = pygame.Surface((2100, 2100), pygame.SRCALPHA)  # dessa två behöver vara
    entladdbild = pygame.Surface((2100, 2100), pygame.SRCALPHA)  # transparenta
    bakgrundsbild = pygame.Surface((2100, 2100))
    bakladdbild = pygame.Surface((2100, 2100))

    spelare = []


    # det här behöver tydligen vara före .convert_alpha, så det måste vara före laddningen av alla bilder
    gameDisplay = pygame.display.set_mode((1000, 600), pygame.RESIZABLE | pygame.SCALED)



    bildlista = []
    bilder = []
    for bild in os.listdir(".bilder"):
        if not bild.lower().__contains__("svilq"):
            bildlista.append(bild.lower().replace(".png", "") + "bild")
            bilder.append(pygame.image.load(".bilder/" + bild).convert_alpha())
            if not bild.lower().__contains__("bakgrund") and not bild.lower().__contains__("logga"):
                # laddar inte vissa bilder i miniversion, man kan t.ex. inte hålla i en bakgrund

                size = bilder[bildlista.index(bild.lower().replace(".png", "") + "bild")].get_size()
                bildlista.append(bild.lower().replace(".png", "") + "liten")
                bilder.append(pygame.transform.scale(
                    bilder[bildlista.index(bild.lower().replace(".png", "") + "bild")],
                    (int(size[0] / 3), int(size[1] / 3))).convert_alpha())

                # laddar både vanliga bilden och en liten version av den

    svilqbilder = []
    for num in range(0, 5):
        svilqbilder.append(pygame.image.load(".bilder/Svilq" + str(num) + ".png").convert_alpha())

    start_new_thread(cinect, (None,))

    # surfacen som används för att blittas på terrängen när det är "superdag"
    whiterect = pygame.Surface((1000, 600))
    whiterect.set_alpha(63)
    whiterect.fill((255, 255, 255))

    clock = pygame.time.Clock()

    while True:
        if stopp[0]:
            quit()

        if update:  # ska vara först så att man sen ändå rör sig samma frame. Om det är sist så rör man sig och sen
            # hoppar man tillbaka pyttelite

            entiteterbild = entladdbild.copy()
            bakgrundsbild = bakladdbild.copy()

            # Den räknar ut ens nya x och y baserat på var den nya delen ligger i förhållande till den gamla.
            # Detta är bra för då om man gått in i en ny del under uppdateringen så kommer x eller y vara för stora
            # eller små och en ny update kommer genast ske
            if forradel[0] < ensdel[0]:
                x -= 700
            elif forradel[0] > ensdel[0]:
                x += 700
            if forradel[1] < ensdel[1]:
                y -= 700
            elif forradel[1] > ensdel[1]:
                y += 700

            update = False

        tid = clock.tick(60)
        custom_speed = tid * 0.001 * serverns_hastighetsorder

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                order.append("EXIT")
            if event.type == pygame.KEYDOWN:
                key = pygame.key.get_pressed()
                if not any("x:" in string for string in order) and not any("v:" in string for string in order):
                    # man får inte skicka flera x och y order på samma gång, så den kollar helt enkelt om order
                    # innehåller något av dem
                    if key[pygame.K_x]:
                        order.append("x:" + str(int(x + krysspos[hall][0])) + "." + str(int(y + krysspos[hall][1])))
                    if key[pygame.K_v]:
                        if 701 > x > -1 and 701 > y > -1:
                            if handen is not None:
                                size = vaxtsizes[vaxtlista.index(handen)]  # used to sätta ut växten i mitten på krysset

                                order.append("v:" + str(int(x + krysspos[hall][0] - size[0] / 2)) + "." + str(int(
                                    y + krysspos[hall][1] - size[1] / 2)))
                                order.append("rw")  # ryggsäck waitaminute
                                if ryggsack.__contains__(handen):
                                    ryggsack.pop(ryggsack.index(handen))
                                else:
                                    handen = None
                if key[pygame.K_r]:
                    order.append("r")

                if key[pygame.K_c] or (key[pygame.K_t] and not ryggsackoppen):
                    meddelande = pygame_input(gameDisplay, "", "", False, (10, 560), escapework=True)
                    if meddelande:
                        order.append("c:" + meddelande)  # c = chatt

                if ryggsackoppen:
                    if key[pygame.K_ESCAPE]:
                        order.append("r")

                    if key[pygame.K_LEFT]:
                        if rvald - 1 >= 0:
                            rvald -= 1
                            fixa_ryggsacksbilden(rvald)
                    if key[pygame.K_RIGHT]:
                        if rvald + 1 < len(ryggsack):
                            rvald += 1
                            fixa_ryggsacksbilden(rvald)
                    if key[pygame.K_UP]:
                        if rvald - 5 >= 0:
                            rvald -= 5
                            fixa_ryggsacksbilden(rvald)
                    if key[pygame.K_DOWN]:
                        if rvald + 5 < len(ryggsack):
                            rvald += 5
                            fixa_ryggsacksbilden(rvald)
                    if key[pygame.K_t]:
                        if handen is not None:
                            order.append("t")
                            order.append("rw")  # ryggsäck waitaminute
                            handen = None
                    if key[pygame.K_h] and ryggsack:  # sätt i handen
                        handen = ryggsack[rvald]
                        order.append("h:" + str(rvald))
                        order.append("rw")
                    if key[pygame.K_s]:  # smash
                        order.append("s:" + str(rvald))
                        # OBS! s från servern betyder spelare, men från klienten smash
                        order.append("rw")  # ryggsäck waitaminute
                    if key[pygame.K_g]:  # gruppsmash
                        order.append("g:" + str(rvald))
                        order.append("rw")  # ryggsäck waitaminute

                    if key[pygame.K_KP_ENTER] or key[pygame.K_RETURN]:
                        nej = False
                        irvald = 0  # i ryggsäcken-meny vald
                        while not nej:
                            for event2 in pygame.event.get():
                                if event2.type == pygame.KEYDOWN:
                                    key2 = pygame.key.get_pressed()
                                    if key2[pygame.K_KP_ENTER] or key2[pygame.K_RETURN]:
                                        nej = True
                                        if irvald == 1:  # sätt i handen
                                            handen = ryggsack[rvald]
                                            order.append("h:" + str(rvald))
                                            order.append("rw")  # ryggsäck waitaminute
                                        if irvald == 2:  # smasha
                                            order.append("s:" + str(rvald))
                                            # OBS! s från servern betyder spelare, men från klienten smash
                                            order.append("rw")  # ryggsäck waitaminute
                                        if irvald == 3:  # gruppsmasha
                                            order.append("g:" + str(rvald))
                                            order.append("rw")  # ryggsäck waitaminute
                                    if key2[pygame.K_ESCAPE]:
                                        nej = True
                                    if key2[pygame.K_r]:
                                        nej = True
                                        order.append("r")
                                    if key2[pygame.K_DOWN]:
                                        if irvald + 1 < 4:
                                            irvald += 1
                                    if key2[pygame.K_UP]:
                                        if irvald - 1 >= 0:
                                            irvald -= 1
                            gameDisplay.fill((45, 67, 87), (100, 100, 800, 400))
                            skriv(gameDisplay, "Avbryt", (200, 200), 50)
                            skriv(gameDisplay, "Sätt i handen", (200, 270), 50)
                            skriv(gameDisplay, "Smasha", (200, 340), 50)
                            skriv(gameDisplay, "Gruppsmasha", (200, 410), 50)
                            gameDisplay.fill((0, 255, 0), (200, 238 + irvald * 70, 200, 5))
                            pygame.display.update()

        if not ryggsackoppen:
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                x -= custom_speed
                hall = 1
            if keys[pygame.K_RIGHT]:
                x += custom_speed
                hall = 3
            if keys[pygame.K_UP]:
                y -= custom_speed
                hall = 0
            if keys[pygame.K_DOWN]:
                y += custom_speed
                hall = 2

        if bot:
            if random.randint(1, 500) == 1:
                hall = random.randint(0, 3)
            if hall == 1:
                x -= custom_speed
            if hall == 3:
                x += custom_speed
            if hall == 0:
                y -= custom_speed
            if hall == 2:
                y += custom_speed

        gameDisplay.fill((255, 255, 255))  # no idea why this is still here (eller jo om man då har extremt dålig
        # överföring och går utanför sin inladdade 3x3-bild så är det vitt där)

        # här blittas bakgrunden till alla delar, som beror på miljön
        gameDisplay.blit(bakgrundsbild, (-700 - x + 480, -700 - y + 280))

        # under här blittas alla andra spelare
        for s in spelare:

            plusx, plusy = 0, 0
            if s[1] < ensdel[0]:
                plusx = -700
            elif s[1] > ensdel[0]:
                plusx = 700
            if s[2] < ensdel[1]:
                plusy = -700
            elif s[2] > ensdel[1]:
                plusy = 700

            gameDisplay.blit(pygame.transform.rotate(svilqbilder[s[6]], s[5] * 90), (s[3] + plusx + 480 - x,
                                                                                     s[4] + plusy + 280 - y))
            skriv(gameDisplay, s[0], (s[3] + plusx + 480 - x, s[4] + plusy + 280 - y))

        # man själv blittas
        gameDisplay.blit(pygame.transform.rotate(svilqbilder[playertype], hall * 90), (480, 280))

        # här blittas alla växter, ovanpå eventuella spelare
        gameDisplay.blit(entiteterbild, (-700 - x + 480, -700 - y + 280))

        # här blittas minimappen
        gameDisplay.fill((156, 75, 101), (845, 445, 110, 110))
        gameDisplay.blit(pygame.transform.scale(bakgrundsbild, (100, 100)), (850, 450))

        # krysset blittas
        gameDisplay.blit(bilder[bildlista.index("kryssbild")], (480 + krysspos[hall][0], 280 + krysspos[hall][1]))
        # det man håller i handen blittas, och korrigeras så att krysset hamnar i mitten på bilden
        if handen is not None:
            size = bilder[bildlista.index(handen + "liten")].get_size()
            gameDisplay.blit(bilder[bildlista.index(handen + "liten")],
                             (480 + krysspos[hall][0] - size[0] / 2, 280 + krysspos[hall][1] - size[1] / 2))

        # allting blir lite ljusare om det är dag-dag
        if dagtid:
            gameDisplay.blit(whiterect, (0, 0))

        # ens position skrivs
        gameDisplay.fill((255, 255, 255), (0, 0, 170, 25))
        skriv(gameDisplay, str(ensdel[0]) + "," + str(ensdel[1]) + "*" + str(int(x)) + "," + str(int(y)))

        # skrivs hur många hugg man har
        gameDisplay.fill((255, 255, 255), (850, 0, 170, 25))
        skriv(gameDisplay, "Hugg: " + str(hugg), (880, 0))

        # här skrivs chatten
        if chatt:
            yc = 530

            chattrev = chatt.copy()
            chattrev.reverse()

            num = 0

            for ch in chattrev:
                if ch.__contains__("~"):
                    colval = ch.split("~")[1].split(",")  # colorvalues
                    skriv(gameDisplay, ch.split("~")[0], (10, yc), 30, (int(colval[0]), int(colval[1]), int(colval[2])))
                else:
                    skriv(gameDisplay, ch, (10, yc))
                yc -= 40
                num += 1
                if num > 4:
                    break

        # ritar ryggsäcken
        if ryggsackoppen:
            gameDisplay.blit(ryggsackbild, (100, 100))

        # whatever
        pygame.display.update()


if __name__ == "__main__":
    stoppu = [False]
    client(stoppu, input("IP: "))
