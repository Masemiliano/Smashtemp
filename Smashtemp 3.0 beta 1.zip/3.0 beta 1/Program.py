import time
import pygame

from server import server
from client import client
from _thread import start_new_thread
from multiprocessing import Process

from classes import *


def main():
    pygame.init()

    display = pygame.display.set_mode((1000, 600), pygame.RESIZABLE | pygame.SCALED)

    pygame.display.set_caption("Smashtemp 3.0 beta 1")

    logga = pygame.transform.scale(pygame.image.load(".bilder/Logga.png"), (1000, 600))

    try:
        fil = open(".data/Playerdata", "r")
        data = fil.read()
        namn = data.split("\n")[0]
        playertype = int(data.split("\n")[1])
        fil.close()
    except FileNotFoundError:
        namn = pygame_input(display, "Vad vill du kallas? ")

        while not namn:
            namn = pygame_input(display, "Vad vill du kallas? ")

        playertype = 0

        fil = open(".data/Playerdata", "w")
        fil.write(namn + "\n" + str(playertype))
        fil.close()

    singleknapp = knapp(display, "Singleplayer", (200, 150))
    joinaknapp = knapp(display, "Joina en server", (200, 250))
    hostaknapp = knapp(display, "Hosta en server", (200, 350))
    bytaknapp = knapp(display, "Byt namn och utseende", (200, 450))

    while True:
        display.fill((0, 50, 67))
        display.blit(logga, (0, 0))

        singleknapp.rita()
        joinaknapp.rita()
        hostaknapp.rita()
        bytaknapp.rita()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if singleknapp.ar_aktiv():
                    stoppcheck = [False]

                    varld = pygame_input(display, "Värld: ")
                    try:
                        fil = open(".data/.världar/" + varld + "/seed", "r")
                        p = Process(daemon=True, target=server, args=(varld, False, fil.read()))
                        fil.close()
                    except FileNotFoundError:
                        p = Process(daemon=True, target=server, args=(varld, False, pygame_input(display, "Seed:")))

                    p.start()

                    pygame.quit()
                    start_new_thread(client, (stoppcheck, "localhost"))

                    while True:
                        time.sleep(2)
                        if stoppcheck[0]:
                            quit()

                if joinaknapp.ar_aktiv():
                    stoppcheck = [False]

                    ip = pygame_input(display, "IP:", "192.168.")

                    pygame.quit()
                    start_new_thread(client, (stoppcheck, ip))

                    while True:
                        time.sleep(2)
                        if stoppcheck[0]:
                            quit()
                if hostaknapp.ar_aktiv():
                    stoppcheck = [False]

                    varld = pygame_input(display, "Värld: ")
                    try:
                        fil = open(".data/.världar/" + varld + "/seed", "r")
                        p = Process(daemon=True, target=server, args=(varld, True, fil.read()))
                        fil.close()
                    except FileNotFoundError:
                        p = Process(daemon=True, target=server, args=(varld, True, pygame_input(display, "Seed:")))

                    p.start()

                    pygame.quit()
                    start_new_thread(client, (stoppcheck, "localhost"))

                    while True:
                        time.sleep(20)

                if bytaknapp.ar_aktiv():

                    ####################totalt meningslös men episk bakgrundsgenerator#####################
                    newsur = pygame.Surface((1000, 600))
                    color = [random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)]
                    for yh in range(0, 600):
                        newsur.fill(color, (0, yh, 1000, 1))
                        color[0] += random.randint(-5, 5)
                        color[1] += random.randint(-5, 5)
                        color[2] += random.randint(-5, 5)

                        if color[0] > 255:
                            color[0] = 255
                        if color[1] > 255:
                            color[1] = 255
                        if color[2] > 255:
                            color[2] = 255
                        if color[0] < 0:
                            color[0] = 0
                        if color[1] < 0:
                            color[1] = 0
                        if color[2] < 0:
                            color[2] = 0
                    #######################################################################################

                    tillbakaknapp = knapp(display, "<- tillbaka", (5, 5), 50, (255, 0, 0))
                    namnknapp = knapp(display, namn, (150, 275))
                    utseendeknapp = knapp(display, "    ---->              ", (500, 275))

                    svilqbilder = []
                    for num in range(0, 5):
                        svilqbilder.append(pygame.image.load(".bilder/Svilq" + str(num) + ".png"))

                    gogogo = True
                    while gogogo:
                        display.blit(newsur, (0, 0))

                        pygame.draw.rect(display, (0, 0, 0), (0, 0, 175, 50))
                        tillbakaknapp.rita()

                        pygame.draw.rect(display, (50, 50, 50), (140, 265, get_textsize(namn, 50)[0] + 20, 54))
                        namnknapp.rita()

                        pygame.draw.rect(display, (50, 50, 50), (490, 265, 246, 54))
                        utseendeknapp.rita()
                        display.blit(svilqbilder[playertype], (625, 280))

                        for eventh in pygame.event.get():
                            if eventh.type == pygame.QUIT:
                                quit()
                            if eventh.type == pygame.MOUSEBUTTONDOWN:
                                if tillbakaknapp.ar_aktiv():
                                    gogogo = False
                                if namnknapp.ar_aktiv():
                                    nyttnamn = pygame_input(display, "Vad vill du kallas? ")
                                    if nyttnamn:
                                        namn = nyttnamn
                                        fil = open(".data/Playerdata", "w")
                                        fil.write(namn + "\n" + str(playertype))
                                        fil.close()
                                        namnknapp.text = namn
                                if utseendeknapp.ar_aktiv():
                                    playertype += 1
                                    if playertype > 4:
                                        playertype = 0
                                    fil = open(".data/Playerdata", "w")
                                    fil.write(namn + "\n" + str(playertype))
                                    fil.close()

                        pygame.display.update()

        pygame.display.update()


if __name__ == "__main__":
    main()
